package dev.spectra.ui;

import dev.spectra.Spectra;
import dev.spectra.module.Category;
import dev.spectra.module.Module;
import dev.spectra.modules.client.GuiSize;
import dev.spectra.setting.BooleanSetting;
import dev.spectra.setting.ColorSetting;
import dev.spectra.setting.KeybindSetting;
import dev.spectra.setting.ModeSetting;
import dev.spectra.setting.NumberSetting;
import dev.spectra.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Three category panels side by side.
 * Tap a row -> toggle the module. Tap the arrow on the right -> open its settings.
 *
 * SIZING: everything is laid out in a virtual coordinate space and then scaled once.
 * The vanilla GUI scale factor on phones is 3-4, which made the old menu enormous;
 * here the menu is pinned to reference factor 2 and then multiplied by the user's
 * Gui Size setting, so it looks the same regardless of the vanilla GUI scale.
 */
public class SpectraScreen extends Screen {
	/** GUI scale factor the layout is designed for. */
	private static final int REFERENCE_SCALE = 2;

	private static final int GAP = 10;
	private static final int HEADER_H = 22;
	private static final int SEARCH_H = 16;

	private static final int C_BG = 0xE0101014;
	private static final int C_HEADER = 0xFF17171C;
	private static final int C_HOVER = 0x30FFFFFF;
	private static final int C_TEXT = 0xFFB9B9C3;
	private static final int C_TEXT_ON = 0xFFFFFFFF;
	private static final int C_ACCENT = 0xFF6C8CFF;
	private static final int C_DIM = 0x40FFFFFF;

	private final List<Panel> panels = new ArrayList<>();

	// layout, recomputed every frame from the current settings
	private float scale = 1.0f;
	private int panelW = 195;
	private int panelH = 400;
	private int rowH = 18;
	private int originX;
	private int originY;

	private String searchText = "";
	private boolean searchFocused;
	private String tooltip;

	private KeybindSetting listeningKeybind;
	private Module listeningModule;
	private NumberSetting draggingNumber;
	private ColorSetting draggingColor;
	private int dragX;
	private int dragW;

	public SpectraScreen() {
		super(Text.literal(Spectra.NAME));
		for (Category category : Category.values()) {
			panels.add(new Panel(category));
		}
	}

	// ------------------------------------------------------------- layout

	private void computeLayout() {
		GuiSize guiSize = Spectra.modules().get(GuiSize.class);
		double multiplier = guiSize != null ? guiSize.scale.getValue() : 1.0;
		panelW = guiSize != null ? guiSize.panelWidth.getInt() : 195;
		rowH = guiSize != null ? guiSize.rowHeight.getInt() : 18;

		int factor = 2;
		if (this.client != null && this.client.getWindow() != null) {
			factor = this.client.getWindow().calculateScaleFactor(
					this.client.options.getGuiScale().getValue(),
					this.client.forcesUnicodeFont());
		}
		if (factor < 1) factor = 1;

		scale = (float) (REFERENCE_SCALE / (float) factor * multiplier);
		if (scale < 0.25f) scale = 0.25f;

		int virtualW = (int) (this.width / scale);
		int virtualH = (int) (this.height / scale);

		// never taller than the screen, and leave room for the search bar
		panelH = Math.min(400, virtualH - 60);
		if (panelH < 120) panelH = 120;

		int columns = panels.size();
		int totalW = columns * panelW + (columns - 1) * GAP;

		// if the panels do not fit sideways, shrink them instead of overflowing
		if (totalW > virtualW - 16) {
			panelW = Math.max(110, (virtualW - 16 - (columns - 1) * GAP) / columns);
			totalW = columns * panelW + (columns - 1) * GAP;
		}

		originX = (virtualW - totalW) / 2;
		originY = (virtualH - panelH) / 2 + 8;

		for (int i = 0; i < columns; i++) {
			Panel panel = panels.get(i);
			panel.x = originX + i * (panelW + GAP);
			panel.y = originY;
		}
	}

	private double vx(double mouseX) {
		return mouseX / scale;
	}

	private double vy(double mouseY) {
		return mouseY / scale;
	}

	// ------------------------------------------------------------- render

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		tooltip = null;
		this.renderBackground(context, mouseX, mouseY, delta);
		computeLayout();

		int mx = (int) vx(mouseX);
		int my = (int) vy(mouseY);

		context.getMatrices().push();
		context.getMatrices().scale(scale, scale, 1.0f);

		// search bar
		int searchY = originY - SEARCH_H - 6;
		int searchW = Math.min(180, panelW);
		context.fill(originX, searchY, originX + searchW, searchY + SEARCH_H, C_HEADER);
		context.fill(originX, searchY + SEARCH_H - 1, originX + searchW, searchY + SEARCH_H,
				searchFocused ? C_ACCENT : C_DIM);
		String searchLabel = searchText.isEmpty() && !searchFocused
				? "Search..."
				: searchText + (searchFocused ? "_" : "");
		context.drawTextWithShadow(this.textRenderer, searchLabel, originX + 5, searchY + 4,
				searchText.isEmpty() && !searchFocused ? C_DIM : C_TEXT_ON);

		context.drawTextWithShadow(this.textRenderer, Spectra.NAME,
				originX + searchW + 8, searchY + 4, C_ACCENT);

		for (Panel panel : panels) {
			panel.render(context, mx, my);
		}

		if (tooltip != null) {
			int w = this.textRenderer.getWidth(tooltip) + 12;
			int virtualW = (int) (this.width / scale);
			int x = Math.max(4, (virtualW - w) / 2);
			int y = Math.max(2, searchY - 22);
			context.fill(x, y, x + w, y + 17, 0xF0101014);
			context.fill(x, y, x + w, y + 1, C_ACCENT);
			context.drawTextWithShadow(this.textRenderer, tooltip, x + 6, y + 5, C_TEXT_ON);
		}

		String hint = (listeningKeybind != null || listeningModule != null)
				? "Press a key... (ESC clears)"
				: "Profile: " + Spectra.config().getProfile();
		context.drawTextWithShadow(this.textRenderer, hint, originX, originY + panelH + 5, C_TEXT);

		context.getMatrices().pop();
	}

	// ------------------------------------------------------------- input

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		computeLayout();
		double mx = vx(mouseX);
		double my = vy(mouseY);

		int searchY = originY - SEARCH_H - 6;
		int searchW = Math.min(180, panelW);
		if (mx >= originX && mx <= originX + searchW && my >= searchY && my <= searchY + SEARCH_H) {
			searchFocused = true;
			return true;
		}
		searchFocused = false;

		for (Panel panel : panels) {
			if (panel.mouseClicked(mx, my, button)) return true;
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	/**
	 * Sliders are dragged by DELTA, not by absolute mouse position.
	 *
	 * WHY: the absolute version computed the value from mouseX / scale, but Gui Size's
	 * own Scale slider feeds back into that same scale. Bigger scale -> smaller virtual
	 * mouseX -> smaller value -> smaller scale -> bigger virtual mouseX, so the menu
	 * oscillated small/big every frame as long as the finger was held down. Delta-based
	 * dragging has no absolute mapping, so the loop cannot form.
	 */
	@Override
	public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
		if (draggingNumber != null) {
			draggingNumber.setFromFraction(draggingNumber.getFraction() + dragStep(deltaX));
			return true;
		}
		if (draggingColor != null) {
			double hue = draggingColor.getHue() + dragStep(deltaX);
			draggingColor.setHue((float) Math.max(0.0, Math.min(1.0, hue)));
			return true;
		}
		return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
	}

	/** Converts a real-pixel mouse delta into a 0..1 fraction delta on the active track. */
	private double dragStep(double deltaX) {
		double trackPixels = dragW * scale;
		if (trackPixels < 1.0) trackPixels = 1.0;
		return deltaX / trackPixels;
	}

	@Override
	public boolean mouseReleased(double mouseX, double mouseY, int button) {
		if (draggingNumber != null || draggingColor != null) {
			draggingNumber = null;
			draggingColor = null;
			Spectra.config().save();
			return true;
		}
		return super.mouseReleased(mouseX, mouseY, button);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
		double mx = vx(mouseX);
		double my = vy(mouseY);
		for (Panel panel : panels) {
			if (panel.isHovered(mx, my)) {
				panel.scroll(vertical * -rowH);
				return true;
			}
		}
		return super.mouseScrolled(mouseX, mouseY, horizontal, vertical);
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (listeningKeybind != null || listeningModule != null) {
			int value = keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode;
			if (listeningKeybind != null) listeningKeybind.setValue(value);
			if (listeningModule != null) listeningModule.setKeybind(value);
			listeningKeybind = null;
			listeningModule = null;
			Spectra.config().save();
			return true;
		}

		if (keyCode == GLFW.GLFW_KEY_F && (modifiers & GLFW.GLFW_MOD_CONTROL) != 0) {
			searchFocused = true;
			return true;
		}

		if (searchFocused) {
			if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
				if (!searchText.isEmpty()) {
					searchText = searchText.substring(0, searchText.length() - 1);
					resetScroll();
				}
				return true;
			}
			if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
				if (!searchText.isEmpty()) {
					searchText = "";
					resetScroll();
				} else {
					searchFocused = false;
				}
				return true;
			}
			if (keyCode == GLFW.GLFW_KEY_ENTER) {
				searchFocused = false;
				return true;
			}
		}

		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean charTyped(char chr, int modifiers) {
		if (searchFocused && chr >= ' ' && chr != 127) {
			searchText += chr;
			resetScroll();
			return true;
		}
		return super.charTyped(chr, modifiers);
	}

	private void resetScroll() {
		for (Panel panel : panels) {
			panel.scrollOffset = 0;
		}
	}

	@Override
	public void close() {
		Spectra.config().save();
		super.close();
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	private String filter() {
		return searchText.trim().toLowerCase();
	}

	// ------------------------------------------------------------- panel

	private class Panel {
		private final Category category;
		private int x;
		private int y;
		private double scrollOffset;
		private Module open;

		private Panel(Category category) {
			this.category = category;
		}

		private boolean isHovered(double mx, double my) {
			return mx >= x && mx <= x + panelW && my >= y && my <= y + panelH;
		}

		private void scroll(double amount) {
			scrollOffset = Math.max(0, Math.min(maxScroll(), scrollOffset + amount));
		}

		private int contentHeight() {
			return open != null
					? (open.getSettings().size() + 1) * rowH
					: visibleModules().size() * rowH;
		}

		private double maxScroll() {
			return Math.max(0, contentHeight() - (panelH - HEADER_H));
		}

		private List<Module> visibleModules() {
			String filter = filter();
			List<Module> result = new ArrayList<>();
			for (Module module : Spectra.modules().getModules(category)) {
				if (filter.isEmpty() || module.getName().toLowerCase().contains(filter)) {
					result.add(module);
				}
			}
			return result;
		}

		private void render(DrawContext context, int mx, int my) {
			context.fill(x, y, x + panelW, y + panelH, C_BG);
			context.fill(x, y, x + panelW, y + HEADER_H, C_HEADER);
			context.fill(x, y + HEADER_H - 1, x + panelW, y + HEADER_H, C_ACCENT);

			String title = open == null ? category.getDisplayName() : "< " + open.getName();
			context.drawTextWithShadow(textRenderer, title, x + 7, y + 7, C_TEXT_ON);

			context.enableScissor(x, y + HEADER_H, x + panelW, y + panelH);
			if (open == null) {
				renderModules(context, mx, my);
			} else {
				renderSettings(context, mx, my);
			}
			context.disableScissor();

			// scrollbar
			if (maxScroll() > 0) {
				int trackH = panelH - HEADER_H;
				int barH = Math.max(12, (int) (trackH * (trackH / (double) contentHeight())));
				int barY = y + HEADER_H + (int) ((trackH - barH) * (scrollOffset / maxScroll()));
				context.fill(x + panelW - 2, barY, x + panelW, barY + barH, C_ACCENT);
			}
		}

		private void renderModules(DrawContext context, int mx, int my) {
			int rowY = y + HEADER_H - (int) scrollOffset;
			int textY = (rowH - 8) / 2;

			for (Module module : visibleModules()) {
				boolean hovered = my >= rowY && my < rowY + rowH && mx >= x && mx <= x + panelW;
				if (hovered) {
					context.fill(x, rowY, x + panelW, rowY + rowH, C_HOVER);
					tooltip = module.getDescription();
				}

				int boxY = rowY + (rowH - 6) / 2;
				context.fill(x + 6, boxY, x + 12, boxY + 6, module.isEnabled() ? C_ACCENT : C_DIM);
				context.drawTextWithShadow(textRenderer, module.getName(), x + 19, rowY + textY,
						module.isEnabled() ? C_TEXT_ON : C_TEXT);

				if (module.hasSettings()) {
					context.drawTextWithShadow(textRenderer, ">", x + panelW - 13, rowY + textY, C_TEXT);
				}

				rowY += rowH;
			}
		}

		private void renderSettings(DrawContext context, int mx, int my) {
			int rowY = y + HEADER_H - (int) scrollOffset;
			int textY = (rowH - 8) / 2;

			for (Setting<?> setting : open.getSettings()) {
				if (my >= rowY && my < rowY + rowH) {
					context.fill(x, rowY, x + panelW, rowY + rowH, C_HOVER);
				}
				context.drawTextWithShadow(textRenderer, setting.getName(), x + 7, rowY + textY, C_TEXT);

				if (setting instanceof BooleanSetting bool) {
					int bx = x + panelW - 25;
					int by = rowY + (rowH - 8) / 2;
					context.fill(bx, by, bx + 16, by + 8, C_DIM);
					if (bool.getValue()) {
						context.fill(bx + 8, by, bx + 16, by + 8, C_ACCENT);
					} else {
						context.fill(bx, by, bx + 8, by + 8, 0x60FFFFFF);
					}
				} else if (setting instanceof NumberSetting number) {
					int sx = x + panelW - 84;
					int sw = 56;
					int sy = rowY + rowH / 2 - 1;
					context.fill(sx, sy, sx + sw, sy + 2, C_DIM);
					context.fill(sx, sy, sx + (int) (sw * number.getFraction()), sy + 2, C_ACCENT);
					String label = formatNumber(number.getValue());
					context.drawTextWithShadow(textRenderer, label,
							x + panelW - 6 - textRenderer.getWidth(label), rowY + textY, C_TEXT_ON);
				} else if (setting instanceof ModeSetting mode) {
					String label = mode.getValue();
					context.drawTextWithShadow(textRenderer, label,
							x + panelW - 7 - textRenderer.getWidth(label), rowY + textY, C_ACCENT);
				} else if (setting instanceof ColorSetting color) {
					int sx = x + panelW - 72;
					int sw = 48;
					int sy = rowY + (rowH - 6) / 2;
					for (int i = 0; i < sw; i++) {
						context.fill(sx + i, sy, sx + i + 1, sy + 6,
								0xFF000000 | java.awt.Color.HSBtoRGB(i / (float) sw, 1.0f, 1.0f));
					}
					int knob = sx + (int) (sw * color.getHue());
					context.fill(knob - 1, sy - 2, knob + 1, sy + 8, 0xFFFFFFFF);
					context.fill(x + panelW - 19, sy, x + panelW - 7, sy + 6, color.getValue() | 0xFF000000);
				} else if (setting instanceof KeybindSetting keybind) {
					String label = listeningKeybind == keybind ? "..." : keybind.getDisplayName();
					context.drawTextWithShadow(textRenderer, label,
							x + panelW - 7 - textRenderer.getWidth(label), rowY + textY, C_ACCENT);
				}

				rowY += rowH;
			}

			if (my >= rowY && my < rowY + rowH) {
				context.fill(x, rowY, x + panelW, rowY + rowH, C_HOVER);
				tooltip = "Key that toggles " + open.getName();
			}
			context.drawTextWithShadow(textRenderer, "Toggle bind", x + 7, rowY + textY, C_TEXT);
			String bindLabel = listeningModule == open ? "..." : keyName(open.getKeybind());
			context.drawTextWithShadow(textRenderer, bindLabel,
					x + panelW - 7 - textRenderer.getWidth(bindLabel), rowY + textY, C_ACCENT);
		}

		private boolean mouseClicked(double mx, double my, int button) {
			if (!isHovered(mx, my)) return false;

			if (my <= y + HEADER_H) {
				if (open != null) {
					open = null;
					scrollOffset = 0;
				}
				return true;
			}

			int index = (int) ((my - y - HEADER_H + scrollOffset) / rowH);
			if (index < 0) return true;

			if (open == null) {
				List<Module> visible = visibleModules();
				if (index >= visible.size()) return true;
				Module module = visible.get(index);

				// wide hit zone on the right so it is tappable with a finger
				boolean onArrow = mx >= x + panelW - 34;
				if (onArrow && module.hasSettings()) {
					open = module;
					scrollOffset = 0;
				} else {
					module.toggle();
					Spectra.config().save();
				}
				return true;
			}

			List<Setting<?>> settings = open.getSettings();
			if (index == settings.size()) {
				listeningModule = open;
				listeningKeybind = null;
				return true;
			}
			if (index > settings.size()) return true;

			Setting<?> setting = settings.get(index);
			if (setting instanceof BooleanSetting bool) {
				bool.toggle();
			} else if (setting instanceof NumberSetting number) {
				draggingNumber = number;
				dragX = x + panelW - 84;
				dragW = 56;
				number.setFromFraction((mx - dragX) / (double) dragW);
			} else if (setting instanceof ModeSetting mode) {
				mode.cycle(button == 1 ? -1 : 1);
			} else if (setting instanceof ColorSetting color) {
				draggingColor = color;
				dragX = x + panelW - 72;
				dragW = 48;
				color.setHue((float) Math.max(0.0, Math.min(1.0, (mx - dragX) / (double) dragW)));
			} else if (setting instanceof KeybindSetting keybind) {
				listeningKeybind = keybind;
				listeningModule = null;
			}

			Spectra.config().save();
			return true;
		}
	}

	private static String formatNumber(double value) {
		return value == Math.floor(value)
				? String.valueOf((int) value)
				: String.format("%.2f", value);
	}

	private static String keyName(int key) {
		if (key == -1) return "NONE";
		String name = GLFW.glfwGetKeyName(key, 0);
		return name == null ? String.valueOf(key) : name.toUpperCase();
	}
}
