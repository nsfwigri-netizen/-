package dev.spectra.module;

import dev.spectra.modules.utility.LockSlot;
import dev.spectra.modules.visual.NoRender;
import dev.spectra.modules.visual.Zoom;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
	private final List<Module> modules = new ArrayList<>();

	public void registerAll() {
		// Visuals
		register(new NoRender());
		register(new Zoom());

		// Utility
		register(new LockSlot());

		// Client
		// register(new Theme());
	}

	public void register(Module module) {
		modules.add(module);
	}

	public void onTick() {
		for (Module module : modules) {
			if (module.isEnabled()) {
				module.onTick();
			}
		}
	}

	public void onKeyPressed(int key) {
		if (key == -1) return;
		for (Module module : modules) {
			if (module.getKeybind() == key) {
				module.toggle();
			}
		}
	}

	public List<Module> getModules() {
		return modules;
	}

	public List<Module> getModules(Category category) {
		List<Module> result = new ArrayList<>();
		for (Module module : modules) {
			if (module.getCategory() == category) {
				result.add(module);
			}
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public <T extends Module> T get(Class<T> type) {
		for (Module module : modules) {
			if (type.isInstance(module)) {
				return (T) module;
			}
		}
		return null;
	}

	public boolean isEnabled(Class<? extends Module> type) {
		Module module = get(type);
		return module != null && module.isEnabled();
	}
}
