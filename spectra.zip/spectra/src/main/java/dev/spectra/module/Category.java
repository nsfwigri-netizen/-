package dev.spectra.module;

public enum Category {
	VISUALS("Visuals"),
	UTILITY("Utility"),
	CLIENT("Client");

	private final String displayName;

	Category(String displayName) {
		this.displayName = displayName;
	}

	public String getDisplayName() {
		return displayName;
	}
}
