package dev.spectra.ui;

import dev.spectra.Spectra;
import dev.spectra.module.Category;
import dev.spectra.module.Module;
import dev.spectra.setting.BooleanSetting;
import dev.spectra.setting.ColorSetting;
import dev.spectra.setting.KeybindSetting;
import dev.spectra.setting.ModeSetting;
import dev.spectra.setting.NumberSetting;
import dev.spectra.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Three category panels side by side.
 * Tap a row -> toggle the module. Tap the arrow on the right -> open that module's settings.
 */
public class SpectraScreen extends Screen {
	private static final int PANEL_W = 195;
	private static final int PANEL_H = 400;
	private static final int GAP = 10;
	private static final int HEADER_H = 24;
	private static final int ROW_H = 18;
	private static final int ARROW_W = 40;

	private static final int C_BG = 0xE0101014;
	private static final int C_HEADER = 0xFF17171C;
	private static final int C_HOVER = 0x30FFFFFF;
	private static final int C_TEXT = 0xFFB9B9C3;
	private static final int C_TEXT_ON = 0xFFFFFFFF;
	private static final int C_ACCENT = 0xFF6C8CFF;

	private final List<Panel> panels = new ArrayList<>();
	private TextFieldWidget search;
	private String tooltip;

	/** Setting currently waiting for a key press. */
	private KeybindSetting listeningKeybind;
	/** Module row currently waiting for a key press (module toggle bind). */
	private Module listeningModule;
	/** Slider being dragged. */
	private NumberSetting draggingNumber;
	private ColorSetting draggingColor;
	private int dragX;
	private int dragW;

	public SpectraScreen() {
		super(Text.literal(Spectra.NAME));
		for (Category category : Category.values()) {
			panels.add(new Panel(category));
		}
	}

	@Override
	protected void init() {
		int totalW = panels.size() * PANEL_W + (panels.size() - 1) * GAP;
		int startX = (this.width - totalW) / 2;
		int startY = (this.height - PANEL_H) / 2;

		for (int i = 0; i < panels.size(); i++) {
			Panel panel = panels.get(i);
			panel.x = startX + i * (PANEL_W + GAP);
			panel.y = startY;
		}

		search = new TextFieldWidget(this.textRenderer, startX, startY - 26, 160, 18, Text.literal("Search"));
		search.setPlaceholder(Text.literal("Search modules (Ctrl+F)"));
		search.setDrawsBackground(true);
		search.setChangedListener(value -> {
			for (Panel panel : panels) {
				panel.scroll = 0;
			}
		});
		addDrawableChild(search);
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		tooltip = null;
		super.render(context, mouseX, mouseY, delta);

		for (Panel panel : panels) {
			panel.render(context, mouseX, mouseY);
		}

		if (tooltip != null) {
			int w = this.textRenderer.getWidth(tooltip) + 12;
			int x = (this.width - w) / 2;
			int y = panels.get(0).y - 52;
			context.fill(x, y, x + w, y + 18, 0xF0101014);
			context.fill(x, y, x + w, y + 1, C_ACCENT);
			context.drawTextWithShadow(this.textRenderer, tooltip, x + 6, y + 5, C_TEXT_ON);
		}

		String hint = listeningKeybind != null || listeningModule != null
				? "Press a key... (ESC to clear)"
				: "Profile: " + Spectra.config().getProfile();
		context.drawTextWithShadow(this.textRenderer, hint,
				panels.get(0).x, panels.get(0).y + PANEL_H + 6, C_TEXT);
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (super.mouseClicked(mouseX, mouseY, button)) return true;
		for (Panel panel : panels) {
			if (panel.mouseClicked(mouseX, mouseY, button)) return true;
		}
		return false;
	}

	@Override
	public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
		if (draggingNumber != null) {
			draggingNumber.setFromFraction((mouseX - dragX) / (double) dragW);
			return true;
		}
		if (draggingColor != null) {
			float hue = (float) Math.max(0.0, Math.min(1.0, (mouseX - dragX) / (double) dragW));
			draggingColor.setHue(hue);
			return true;
		}
		return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
	}

	@Override
	public boolean mouseReleased(double mouseX, double mouseY, int button) {
		draggingNumber = null;
		draggingColor = null;
		return super.mouseReleased(mouseX, mouseY, button);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
		for (Panel panel : panels) {
			if (panel.isHovered(mouseX, mouseY)) {
				panel.scroll(vertical * -18);
				return true;
			}
		}
		return super.mouseScrolled(mouseX, mouseY, horizontal, vertical);
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		// keybind capture wins over everything
		if (listeningKeybind != null || listeningModule != null) {
			int value = keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode;
			if (listeningKeybind != null) listeningKeybind.setValue(value);
			if (listeningModule != null) listeningModule.setKeybind(value);
			listeningKeybind = null;
			listeningModule = null;
			return true;
		}

		if (keyCode == GLFW.GLFW_KEY_F && (modifiers & GLFW.GLFW_MOD_CONTROL) != 0) {
			search.setFocused(true);
			return true;
		}

		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public void close() {
		Spectra.config().save();
		super.close();
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	private String filter() {
		return search == null ? "" : search.getText().trim().toLowerCase();
	}

	// ---------------------------------------------------------------- panel

	private class Panel {
		private final Category category;
		private int x;
		private int y;
		private double scroll;
		/** null = module list, otherwise the module whose settings are open. */
		private Module open;

		private Panel(Category category) {
			this.category = category;
		}

		private boolean isHovered(double mouseX, double mouseY) {
			return mouseX >= x && mouseX <= x + PANEL_W && mouseY >= y && mouseY <= y + PANEL_H;
		}

		private void scroll(double amount) {
			scroll = Math.max(0, Math.min(maxScroll(), scroll + amount));
		}

		private int contentHeight() {
			if (open != null) {
				return open.getSettings().size() * ROW_H + ROW_H; // + bind row
			}
			return visibleModules().size() * ROW_H;
		}

		private double maxScroll() {
			return Math.max(0, contentHeight() - (PANEL_H - HEADER_H));
		}

		private List<Module> visibleModules() {
			String filter = filter();
			List<Module> result = new ArrayList<>();
			for (Module module : Spectra.modules().getModules(category)) {
				if (filter.isEmpty() || module.getName().toLowerCase().contains(filter)) {
					result.add(module);
				}
			}
			return result;
		}

		private void render(DrawContext context, int mouseX, int mouseY) {
			context.fill(x, y, x + PANEL_W, y + PANEL_H, C_BG);
			context.fill(x, y, x + PANEL_W, y + HEADER_H, C_HEADER);
			context.fill(x, y + HEADER_H - 1, x + PANEL_W, y + HEADER_H, C_ACCENT);

			String title = open == null ? category.getDisplayName() : "< " + open.getName();
			context.drawTextWithShadow(textRenderer, title, x + 8, y + 8, C_TEXT_ON);

			context.enableScissor(x, y + HEADER_H, x + PANEL_W, y + PANEL_H);
			if (open == null) {
				renderModules(context, mouseX, mouseY);
			} else {
				renderSettings(context, mouseX, mouseY);
			}
			context.disableScissor();
		}

		private void renderModules(DrawContext context, int mouseX, int mouseY) {
			int rowY = y + HEADER_H - (int) scroll;
			for (Module module : visibleModules()) {
				boolean hovered = mouseY >= rowY && mouseY < rowY + ROW_H && mouseX >= x && mouseX <= x + PANEL_W;
				if (hovered) {
					context.fill(x, rowY, x + PANEL_W, rowY + ROW_H, C_HOVER);
					tooltip = module.getDescription();
				}

				// enabled marker
				if (module.isEnabled()) {
					context.fill(x + 6, rowY + 6, x + 12, rowY + 12, C_ACCENT);
				} else {
					context.fill(x + 6, rowY + 6, x + 12, rowY + 12, 0x40FFFFFF);
				}

				context.drawTextWithShadow(textRenderer, module.getName(), x + 20, rowY + 5,
						module.isEnabled() ? C_TEXT_ON : C_TEXT);

				if (module.hasSettings()) {
					context.drawTextWithShadow(textRenderer, ">", x + PANEL_W - 14, rowY + 5, C_TEXT);
				}

				rowY += ROW_H;
			}
		}

		private void renderSettings(DrawContext context, int mouseX, int mouseY) {
			int rowY = y + HEADER_H - (int) scroll;

			for (Setting<?> setting : open.getSettings()) {
				boolean hovered = mouseY >= rowY && mouseY < rowY + ROW_H;
				if (hovered) context.fill(x, rowY, x + PANEL_W, rowY + ROW_H, C_HOVER);

				context.drawTextWithShadow(textRenderer, setting.getName(), x + 8, rowY + 5, C_TEXT);

				if (setting instanceof BooleanSetting bool) {
					int bx = x + PANEL_W - 26;
					context.fill(bx, rowY + 5, bx + 16, rowY + 13, 0x40FFFFFF);
					if (bool.getValue()) {
						context.fill(bx + 8, rowY + 5, bx + 16, rowY + 13, C_ACCENT);
					} else {
						context.fill(bx, rowY + 5, bx + 8, rowY + 13, 0x60FFFFFF);
					}
				} else if (setting instanceof NumberSetting number) {
					int sx = x + PANEL_W - 84;
					int sw = 60;
					context.fill(sx, rowY + 8, sx + sw, rowY + 11, 0x40FFFFFF);
					int fill = (int) (sw * number.getFraction());
					context.fill(sx, rowY + 8, sx + fill, rowY + 11, C_ACCENT);
					String label = String.format("%.2f", number.getValue());
					context.drawTextWithShadow(textRenderer, label, x + PANEL_W - 22 - textRenderer.getWidth(label) / 2, rowY + 5, C_TEXT_ON);
				} else if (setting instanceof ModeSetting mode) {
					String label = mode.getValue();
					context.drawTextWithShadow(textRenderer, label,
							x + PANEL_W - 8 - textRenderer.getWidth(label), rowY + 5, C_ACCENT);
				} else if (setting instanceof ColorSetting color) {
					int sx = x + PANEL_W - 74;
					int sw = 50;
					for (int i = 0; i < sw; i++) {
						int rgb = java.awt.Color.HSBtoRGB(i / (float) sw, 1.0f, 1.0f);
						context.fill(sx + i, rowY + 6, sx + i + 1, rowY + 12, 0xFF000000 | rgb);
					}
					int knob = sx + (int) (sw * color.getHue());
					context.fill(knob - 1, rowY + 4, knob + 1, rowY + 14, 0xFFFFFFFF);
					context.fill(x + PANEL_W - 20, rowY + 5, x + PANEL_W - 8, rowY + 13, color.getValue() | 0xFF000000);
				} else if (setting instanceof KeybindSetting keybind) {
					String label = listeningKeybind == keybind ? "..." : keybind.getDisplayName();
					context.drawTextWithShadow(textRenderer, label,
							x + PANEL_W - 8 - textRenderer.getWidth(label), rowY + 5, C_ACCENT);
				}

				rowY += ROW_H;
			}

			// module toggle bind row
			if (mouseY >= rowY && mouseY < rowY + ROW_H) {
				context.fill(x, rowY, x + PANEL_W, rowY + ROW_H, C_HOVER);
				tooltip = "Key that toggles " + open.getName();
			}
			context.drawTextWithShadow(textRenderer, "Toggle bind", x + 8, rowY + 5, C_TEXT);
			String bindLabel = listeningModule == open
					? "..."
					: (open.getKeybind() == -1 ? "NONE" : GLFW.glfwGetKeyName(open.getKeybind(), 0) == null
						? String.valueOf(open.getKeybind())
						: GLFW.glfwGetKeyName(open.getKeybind(), 0).toUpperCase());
			context.drawTextWithShadow(textRenderer, bindLabel,
					x + PANEL_W - 8 - textRenderer.getWidth(bindLabel), rowY + 5, C_ACCENT);
		}

		private boolean mouseClicked(double mouseX, double mouseY, int button) {
			if (!isHovered(mouseX, mouseY)) return false;

			// header: back button
			if (mouseY <= y + HEADER_H) {
				if (open != null) {
					open = null;
					scroll = 0;
				}
				return true;
			}

			int index = (int) ((mouseY - y - HEADER_H + scroll) / ROW_H);
			if (index < 0) return true;

			if (open == null) {
				List<Module> visible = visibleModules();
				if (index >= visible.size()) return true;
				Module module = visible.get(index);

				boolean onArrow = mouseX >= x + PANEL_W - ARROW_W;
				if (onArrow && module.hasSettings()) {
					open = module;
					scroll = 0;
				} else {
					module.toggle();
					Spectra.config().save();
				}
				return true;
			}

			List<Setting<?>> settings = open.getSettings();
			if (index == settings.size()) {
				listeningModule = open;
				listeningKeybind = null;
				return true;
			}
			if (index > settings.size()) return true;

			Setting<?> setting = settings.get(index);
			int rowY = y + HEADER_H + index * ROW_H - (int) scroll;

			if (setting instanceof BooleanSetting bool) {
				bool.toggle();
			} else if (setting instanceof NumberSetting number) {
				draggingNumber = number;
				dragX = x + PANEL_W - 84;
				dragW = 60;
				number.setFromFraction((mouseX - dragX) / (double) dragW);
			} else if (setting instanceof ModeSetting mode) {
				mode.cycle(button == 1 ? -1 : 1);
			} else if (setting instanceof ColorSetting color) {
				draggingColor = color;
				dragX = x + PANEL_W - 74;
				dragW = 50;
				color.setHue((float) Math.max(0.0, Math.min(1.0, (mouseX - dragX) / (double) dragW)));
			} else if (setting instanceof KeybindSetting keybind) {
				listeningKeybind = keybind;
				listeningModule = null;
			}

			Spectra.config().save();
			return true;
		}
	}
}
