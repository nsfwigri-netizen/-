package dev.spectra.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.spectra.Spectra;
import dev.spectra.module.Module;
import dev.spectra.module.ModuleManager;
import dev.spectra.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/** JSON profile storage: config/spectra/<profile>.json */
public class ConfigManager {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private final ModuleManager moduleManager;
	private final Path directory;
	private String profile = "default";

	public ConfigManager(ModuleManager moduleManager) {
		this.moduleManager = moduleManager;
		this.directory = FabricLoader.getInstance().getConfigDir().resolve(Spectra.MOD_ID);
	}

	public void save() {
		JsonObject root = new JsonObject();
		for (Module module : moduleManager.getModules()) {
			JsonObject moduleJson = new JsonObject();
			moduleJson.addProperty("enabled", module.isEnabled());
			moduleJson.addProperty("keybind", module.getKeybind());

			JsonObject settingsJson = new JsonObject();
			for (Setting<?> setting : module.getSettings()) {
				settingsJson.add(setting.getName(), setting.save());
			}
			moduleJson.add("settings", settingsJson);
			root.add(module.getName(), moduleJson);
		}

		try {
			Files.createDirectories(directory);
			Files.writeString(file(profile), GSON.toJson(root));
		} catch (IOException e) {
			Spectra.LOG.error("Failed to save profile {}", profile, e);
		}
	}

	public void load() {
		Path path = file(profile);
		if (!Files.exists(path)) {
			save();
			return;
		}

		try {
			JsonObject root = JsonParser.parseString(Files.readString(path)).getAsJsonObject();
			for (Module module : moduleManager.getModules()) {
				if (!root.has(module.getName())) continue;
				JsonObject moduleJson = root.getAsJsonObject(module.getName());

				if (moduleJson.has("keybind")) {
					module.setKeybind(moduleJson.get("keybind").getAsInt());
				}

				if (moduleJson.has("settings")) {
					JsonObject settingsJson = moduleJson.getAsJsonObject("settings");
					for (Setting<?> setting : module.getSettings()) {
						JsonElement value = settingsJson.get(setting.getName());
						if (value != null) {
							try {
								setting.load(value);
							} catch (Exception ignored) {
								// corrupted value, keep the default
							}
						}
					}
				}

				// enabled last, so onEnable() sees the loaded settings
				if (moduleJson.has("enabled")) {
					module.setEnabled(moduleJson.get("enabled").getAsBoolean());
				}
			}
		} catch (Exception e) {
			Spectra.LOG.error("Failed to load profile {}", profile, e);
		}
	}

	public void switchProfile(String name) {
		save();
		this.profile = name;
		load();
	}

	public List<String> listProfiles() {
		List<String> profiles = new ArrayList<>();
		if (!Files.isDirectory(directory)) return profiles;
		try (Stream<Path> stream = Files.list(directory)) {
			stream.filter(p -> p.toString().endsWith(".json"))
					.forEach(p -> {
						String fileName = p.getFileName().toString();
						profiles.add(fileName.substring(0, fileName.length() - 5));
					});
		} catch (IOException e) {
			Spectra.LOG.error("Failed to list profiles", e);
		}
		return profiles;
	}

	public String getProfile() {
		return profile;
	}

	private Path file(String name) {
		return directory.resolve(name + ".json");
	}
}
