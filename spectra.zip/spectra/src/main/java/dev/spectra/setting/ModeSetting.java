package dev.spectra.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Arrays;
import java.util.List;

public class ModeSetting extends Setting<String> {
	private final List<String> modes;

	public ModeSetting(String name, String defaultValue, String... modes) {
		super(name, defaultValue);
		this.modes = Arrays.asList(modes);
	}

	public void cycle(int direction) {
		int index = modes.indexOf(getValue());
		if (index < 0) index = 0;
		index = (index + direction + modes.size()) % modes.size();
		setValue(modes.get(index));
	}

	public boolean is(String mode) {
		return getValue().equalsIgnoreCase(mode);
	}

	public List<String> getModes() {
		return modes;
	}

	@Override
	public JsonElement save() {
		return new JsonPrimitive(getValue());
	}

	@Override
	public void load(JsonElement element) {
		String loaded = element.getAsString();
		if (modes.contains(loaded)) {
			setValue(loaded);
		}
	}
}
