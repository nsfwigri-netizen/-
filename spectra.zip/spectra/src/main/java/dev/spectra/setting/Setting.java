package dev.spectra.setting;

import com.google.gson.JsonElement;

public abstract class Setting<T> {
	private final String name;
	private final T defaultValue;
	protected T value;

	protected Setting(String name, T defaultValue) {
		this.name = name;
		this.defaultValue = defaultValue;
		this.value = defaultValue;
	}

	public String getName() {
		return name;
	}

	public T getValue() {
		return value;
	}

	public void setValue(T value) {
		this.value = value;
	}

	public void reset() {
		this.value = defaultValue;
	}

	public abstract JsonElement save();

	public abstract void load(JsonElement element);
}
