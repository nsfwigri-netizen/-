package dev.spectra.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.awt.Color;

/** Stores a packed ARGB color. */
public class ColorSetting extends Setting<Integer> {
	public ColorSetting(String name, int defaultArgb) {
		super(name, defaultArgb);
	}

	public void setHue(float hue) {
		int rgb = Color.HSBtoRGB(hue, 1.0f, 1.0f);
		setValue((getAlpha() << 24) | (rgb & 0x00FFFFFF));
	}

	public float getHue() {
		int value = getValue();
		float[] hsb = Color.RGBtoHSB((value >> 16) & 0xFF, (value >> 8) & 0xFF, value & 0xFF, null);
		return hsb[0];
	}

	public int getAlpha() {
		return (getValue() >> 24) & 0xFF;
	}

	public void setAlpha(int alpha) {
		setValue(((alpha & 0xFF) << 24) | (getValue() & 0x00FFFFFF));
	}

	@Override
	public JsonElement save() {
		return new JsonPrimitive(getValue());
	}

	@Override
	public void load(JsonElement element) {
		setValue(element.getAsInt());
	}
}
