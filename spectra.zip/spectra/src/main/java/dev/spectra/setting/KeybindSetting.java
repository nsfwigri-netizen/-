package dev.spectra.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import net.minecraft.client.util.InputUtil;

import org.lwjgl.glfw.GLFW;

/** Stores a raw GLFW key code. -1 means unbound. */
public class KeybindSetting extends Setting<Integer> {
	public KeybindSetting(String name, int defaultKey) {
		super(name, defaultKey);
	}

	public boolean isUnbound() {
		return getValue() == -1 || getValue() == GLFW.GLFW_KEY_UNKNOWN;
	}

	public String getDisplayName() {
		if (isUnbound()) return "NONE";
		return InputUtil.Type.KEYSYM.createFromCode(getValue()).getLocalizedText().getString().toUpperCase();
	}

	@Override
	public JsonElement save() {
		return new JsonPrimitive(getValue());
	}

	@Override
	public void load(JsonElement element) {
		setValue(element.getAsInt());
	}
}
