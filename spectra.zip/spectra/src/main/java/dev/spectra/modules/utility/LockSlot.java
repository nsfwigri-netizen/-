package dev.spectra.modules.utility;

import dev.spectra.module.Category;
import dev.spectra.module.Module;
import dev.spectra.setting.BooleanSetting;

import java.util.ArrayList;
import java.util.List;

/**
 * Blocks moving/dropping items out of chosen hotbar slots.
 * Enforcement lives in HandledScreenMixin (inventory clicks).
 */
public class LockSlot extends Module {
	private final List<BooleanSetting> slots = new ArrayList<>();

	public final BooleanSetting blockDrop = add(new BooleanSetting("Block drop key", true));

	public LockSlot() {
		super("Lock Slot", "Locks hotbar slots so items can't be moved or dropped.", Category.UTILITY);
		for (int i = 1; i <= 9; i++) {
			slots.add(add(new BooleanSetting("Slot " + i, false)));
		}
	}

	/** slotIndex is 0..8 (hotbar order). */
	public boolean isLocked(int slotIndex) {
		if (!isEnabled()) return false;
		if (slotIndex < 0 || slotIndex >= slots.size()) return false;
		return slots.get(slotIndex).getValue();
	}

	public boolean shouldBlockDrop() {
		return isEnabled() && blockDrop.getValue();
	}
}
