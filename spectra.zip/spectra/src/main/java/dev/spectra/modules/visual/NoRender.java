package dev.spectra.modules.visual;

import dev.spectra.module.Category;
import dev.spectra.module.Module;
import dev.spectra.setting.BooleanSetting;
import net.minecraft.client.particle.Particle;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.decoration.painting.PaintingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;

/**
 * Skips rendering of chosen entities, particles and screen effects.
 * Biggest FPS win on mobile, and it costs nothing when every toggle is off.
 *
 * Enforcement points:
 *   EntityRendererMixin#shouldRender  -> entities
 *   ParticleManagerMixin#addParticle  -> particles
 *   EntityFireMixin#doesRenderOnFire  -> fire on entities + first person fire overlay
 *   HurtCameraMixin#tiltViewWhenHurt  -> damage camera tilt
 *
 * Note: the local player is never hidden by "All entities", otherwise third person
 * and the inventory preview break in a way that looks like a crash.
 */
public class NoRender extends Module {
	// entities
	public final BooleanSetting allEntities = add(new BooleanSetting("All entities", false));
	public final BooleanSetting droppedItems = add(new BooleanSetting("Dropped items", false));
	public final BooleanSetting xpOrbs = add(new BooleanSetting("XP orbs", false));
	public final BooleanSetting decoration = add(new BooleanSetting("Frames & paintings", false));
	public final BooleanSetting armorStands = add(new BooleanSetting("Armor stands", false));
	public final BooleanSetting players = add(new BooleanSetting("Other players", false));
	public final BooleanSetting passiveMobs = add(new BooleanSetting("Passive mobs", false));
	public final BooleanSetting hostileMobs = add(new BooleanSetting("Hostile mobs", false));
	public final BooleanSetting projectiles = add(new BooleanSetting("Projectiles", false));

	// particles
	public final BooleanSetting particles = add(new BooleanSetting("All particles", false));

	// screen effects
	public final BooleanSetting fireOverlay = add(new BooleanSetting("Fire overlay", false));
	public final BooleanSetting hurtCamera = add(new BooleanSetting("Hurt camera", false));

	public NoRender() {
		super("NoRender", "Skips rendering of entities, particles and screen effects.", Category.VISUALS);
	}

	public boolean shouldHideEntity(Entity entity) {
		if (!isEnabled() || entity == null) return false;

		// never hide ourselves
		if (mc.player != null && entity == mc.player) return false;

		if (allEntities.getValue()) return true;
		if (droppedItems.getValue() && entity instanceof ItemEntity) return true;
		if (xpOrbs.getValue() && entity instanceof ExperienceOrbEntity) return true;
		if (decoration.getValue() && (entity instanceof ItemFrameEntity || entity instanceof PaintingEntity)) return true;
		if (armorStands.getValue() && entity instanceof ArmorStandEntity) return true;
		if (players.getValue() && entity instanceof PlayerEntity) return true;
		if (passiveMobs.getValue() && entity instanceof PassiveEntity) return true;
		if (hostileMobs.getValue() && entity instanceof HostileEntity) return true;
		if (projectiles.getValue() && entity instanceof ProjectileEntity) return true;

		return false;
	}

	public boolean shouldHideParticle(Particle particle) {
		return isEnabled() && particles.getValue();
	}

	public boolean shouldHideFire() {
		return isEnabled() && fireOverlay.getValue();
	}

	public boolean shouldHideHurtCamera() {
		return isEnabled() && hurtCamera.getValue();
	}
}
