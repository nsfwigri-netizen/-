package dev.spectra.modules.client;

import dev.spectra.module.Category;
import dev.spectra.module.Module;
import dev.spectra.setting.NumberSetting;

/**
 * Controls the size of the Spectra menu itself.
 *
 * The menu is drawn at a fixed reference GUI scale instead of following the vanilla
 * GUI scale option. On phones the vanilla scale factor is usually 3-4, which is why
 * the menu looked enormous: every panel was multiplied by it.
 *
 * Settings here apply even when the module is off, otherwise you could disable it
 * and lose the ability to shrink an unreadably large menu.
 */
public class GuiSize extends Module {
	public final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.5, 2.0, 0.05));
	public final NumberSetting panelWidth = add(new NumberSetting("Panel width", 195, 130, 280, 5));
	public final NumberSetting rowHeight = add(new NumberSetting("Row height", 18, 14, 28, 1));

	public GuiSize() {
		super("Gui Size", "Size of the Spectra menu. Applies even while off.", Category.CLIENT);
	}
}
