package dev.spectra.modules.visual;

import dev.spectra.module.Category;
import dev.spectra.module.Module;
import dev.spectra.setting.BooleanSetting;
import dev.spectra.setting.ModeSetting;
import dev.spectra.setting.NumberSetting;

/**
 * Hand swing speed + preset swing styles.
 *
 * Speed works by overriding LivingEntity#getHandSwingDuration (default 6 ticks).
 * IMPORTANT: this is purely visual. The server decides attack cooldown, so a fast
 * swing does not make you hit faster - it only shortens the animation. That is the
 * single most common misunderstanding with these modules.
 *
 * Style changes the matrix transform applied in HeldItemRendererMixin. Presets are
 * the ones people actually ask for by name, ported to first-person transforms.
 */
public class SwingAnimation extends Module {
	public final NumberSetting duration = add(new NumberSetting("Duration", 6, 1, 20, 1));
	public final BooleanSetting selfOnly = add(new BooleanSetting("Only me", true));
	public final ModeSetting style = add(new ModeSetting("Style", "Vanilla",
			"Vanilla", "Slide", "Stab", "Swank", "Spin", "Exhibition", "Old 1.7"));
	public final NumberSetting strength = add(new NumberSetting("Strength", 1.0, 0.0, 2.0, 0.05));

	public SwingAnimation() {
		super("Swing Animation", "Swing speed and style. Visual only, does not change hit rate.", Category.VISUALS);
	}

	/** Swing length in ticks. Vanilla is 6. */
	public int getDuration() {
		return duration.getInt();
	}

	public boolean isSelfOnly() {
		return selfOnly.getValue();
	}

	public boolean hasStyle() {
		return !style.is("Vanilla");
	}

	public String getStyle() {
		return style.getValue();
	}

	public float getStrength() {
		return strength.getFloat();
	}
}
