package dev.spectra.modules.visual;

import dev.spectra.module.Category;
import dev.spectra.module.Module;
import dev.spectra.setting.BooleanSetting;
import dev.spectra.setting.KeybindSetting;
import dev.spectra.setting.NumberSetting;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Hold-to-zoom. The FOV override itself lives in GameRendererMixin,
 * which reads getCurrentFovScale() every frame.
 *
 * Default bind is V, not C: C collides with the vanilla socialInteractions /
 * other common binds and is the most reported conflict for zoom mods.
 */
public class Zoom extends Module {
	public final NumberSetting amount = add(new NumberSetting("Amount", 4.0, 1.5, 10.0, 0.5));
	public final BooleanSetting smooth = add(new BooleanSetting("Smooth", true));
	public final NumberSetting speed = add(new NumberSetting("Speed", 0.35, 0.05, 1.0, 0.05));
	public final BooleanSetting toggleMode = add(new BooleanSetting("Toggle mode", false));
	public final BooleanSetting keepSensitivity = add(new BooleanSetting("Scale sensitivity", true));
	public final KeybindSetting key = add(new KeybindSetting("Zoom key", GLFW.GLFW_KEY_V));

	private boolean toggled;
	private boolean lastDown;
	private double current = 1.0;

	public Zoom() {
		super("Zoom", "Hold a key to zoom in. Smooth interpolation avoids the snap.", Category.VISUALS);
	}

	@Override
	public void onDisable() {
		toggled = false;
		current = 1.0;
	}

	@Override
	public void onTick() {
		boolean down = isKeyDown();
		if (toggleMode.getValue()) {
			if (down && !lastDown) toggled = !toggled;
		} else {
			toggled = down;
		}
		lastDown = down;

		double target = toggled ? amount.getValue() : 1.0;
		if (smooth.getValue()) {
			current += (target - current) * speed.getValue();
			if (Math.abs(target - current) < 0.001) current = target;
		} else {
			current = target;
		}
	}

	private boolean isKeyDown() {
		if (key.isUnbound() || mc.getWindow() == null) return false;
		return InputUtil.isKeyPressed(mc.getWindow().getHandle(), key.getValue());
	}

	/** 1.0 = no zoom. Divide the FOV by this. */
	public double getCurrentFovScale() {
		return current;
	}

	public boolean isZooming() {
		return current > 1.001;
	}
}
