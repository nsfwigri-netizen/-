package dev.spectra.modules.visual;

import dev.spectra.module.Category;
import dev.spectra.module.Module;
import dev.spectra.setting.BooleanSetting;
import dev.spectra.setting.NumberSetting;

/**
 * Free positioning of the first-person item: offset, scale, rotation.
 * Applied in HeldItemRendererMixin around renderFirstPersonItem.
 *
 * Offsets are in the renderer's local units (1.0 is a whole block), which is why the
 * ranges are small. The offhand is mirrored on X automatically, otherwise the left
 * item flies off in the opposite direction of the right one.
 */
public class ViewModel extends Module {
	public final NumberSetting posX = add(new NumberSetting("Pos X", 0.0, -1.0, 1.0, 0.01));
	public final NumberSetting posY = add(new NumberSetting("Pos Y", 0.0, -1.0, 1.0, 0.01));
	public final NumberSetting posZ = add(new NumberSetting("Pos Z", 0.0, -1.0, 1.0, 0.01));
	public final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.2, 2.5, 0.05));
	public final NumberSetting rotX = add(new NumberSetting("Rot X", 0, -180, 180, 1));
	public final NumberSetting rotY = add(new NumberSetting("Rot Y", 0, -180, 180, 1));
	public final NumberSetting rotZ = add(new NumberSetting("Rot Z", 0, -180, 180, 1));
	public final BooleanSetting mainHandOnly = add(new BooleanSetting("Main hand only", false));
	public final BooleanSetting mirrorOffhand = add(new BooleanSetting("Mirror offhand", true));

	public ViewModel() {
		super("View Model", "Move, scale and rotate the item in your hand.", Category.VISUALS);
	}

	public boolean appliesTo(boolean mainHand) {
		return mainHand || !mainHandOnly.getValue();
	}

	public float x(boolean mainHand) {
		float value = posX.getFloat();
		return (!mainHand && mirrorOffhand.getValue()) ? -value : value;
	}

	public float y() {
		return posY.getFloat();
	}

	public float z() {
		return posZ.getFloat();
	}

	public float scale() {
		return scale.getFloat();
	}

	public float rotX() {
		return rotX.getFloat();
	}

	public float rotY(boolean mainHand) {
		float value = rotY.getFloat();
		return (!mainHand && mirrorOffhand.getValue()) ? -value : value;
	}

	public float rotZ(boolean mainHand) {
		float value = rotZ.getFloat();
		return (!mainHand && mirrorOffhand.getValue()) ? -value : value;
	}
}
