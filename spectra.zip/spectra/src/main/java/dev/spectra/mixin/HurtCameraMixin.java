package dev.spectra.mixin;

import dev.spectra.Spectra;
import dev.spectra.modules.visual.NoRender;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Removes the camera tilt on damage.
 *
 * On 1.21.4 the target is:
 *   private void tiltViewWhenHurt(MatrixStack matrices, float tickProgress)
 * If a mappings bump renames it, fix the method name here.
 */
@Mixin(GameRenderer.class)
public class HurtCameraMixin {
	@Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
	private void spectra$noHurtCam(MatrixStack matrices, float tickProgress, CallbackInfo ci) {
		NoRender noRender = Spectra.modules().get(NoRender.class);
		if (noRender != null && noRender.shouldHideHurtCamera()) {
			ci.cancel();
		}
	}
}
