package dev.spectra.mixin;

import dev.spectra.Spectra;
import dev.spectra.modules.visual.SwingAnimation;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Swing speed override.
 *
 * getHandSwingDuration() is private in LivingEntity (intermediary method_6028) and
 * returns 6 in vanilla, modified by Haste / Mining Fatigue. Overriding it only
 * changes how long the animation plays; the server still gates real attack speed.
 */
@Mixin(LivingEntity.class)
public class LivingEntityMixin {
	@Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true)
	private void spectra$swingDuration(CallbackInfoReturnable<Integer> cir) {
		SwingAnimation module = Spectra.modules().get(SwingAnimation.class);
		if (module == null || !module.isEnabled()) return;

		if (module.isSelfOnly()) {
			LivingEntity self = (LivingEntity) (Object) this;
			if (self != MinecraftClient.getInstance().player) return;
		}

		cir.setReturnValue(module.getDuration());
	}
}
