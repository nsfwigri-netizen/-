package dev.spectra.mixin;

import dev.spectra.Spectra;
import dev.spectra.modules.visual.SwingAnimation;
import dev.spectra.modules.visual.ViewModel;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * First-person item transforms for View Model and Swing Animation styles.
 *
 * Target on 1.21.4 (private, so the signature must match exactly):
 *   private void renderFirstPersonItem(AbstractClientPlayerEntity player, float tickDelta,
 *       float pitch, Hand hand, float swingProgress, ItemStack item, float equipProgress,
 *       MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light)
 *
 * HEAD pushes a matrix and applies the transform, RETURN pops it. RETURN fires at every
 * return point, so push/pop stay balanced even when the method bails out early.
 */
@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
	@Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
	private void spectra$transformHead(AbstractClientPlayerEntity player, float tickDelta, float pitch,
			Hand hand, float swingProgress, ItemStack item, float equipProgress,
			MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
		matrices.push();

		boolean mainHand = hand == Hand.MAIN_HAND;

		ViewModel viewModel = Spectra.modules().get(ViewModel.class);
		if (viewModel != null && viewModel.isEnabled() && viewModel.appliesTo(mainHand)) {
			matrices.translate(viewModel.x(mainHand), viewModel.y(), viewModel.z());
			if (viewModel.rotX() != 0f) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(viewModel.rotX()));
			if (viewModel.rotY(mainHand) != 0f) matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(viewModel.rotY(mainHand)));
			if (viewModel.rotZ(mainHand) != 0f) matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(viewModel.rotZ(mainHand)));
			float scale = viewModel.scale();
			if (scale != 1f) matrices.scale(scale, scale, scale);
		}

		SwingAnimation swing = Spectra.modules().get(SwingAnimation.class);
		if (swing != null && swing.isEnabled() && swing.hasStyle() && swingProgress > 0f) {
			spectra$applyStyle(matrices, swing.getStyle(), swingProgress, swing.getStrength(), mainHand);
		}
	}

	@Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
	private void spectra$transformReturn(AbstractClientPlayerEntity player, float tickDelta, float pitch,
			Hand hand, float swingProgress, ItemStack item, float equipProgress,
			MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
		matrices.pop();
	}

	private static void spectra$applyStyle(MatrixStack matrices, String style, float progress,
			float strength, boolean mainHand) {
		// sin curve so the motion starts and ends at rest instead of snapping back
		float wave = (float) Math.sin(progress * Math.PI) * strength;
		float side = mainHand ? 1f : -1f;

		switch (style) {
			case "Slide" -> {
				matrices.translate(-wave * 0.35f * side, 0f, wave * 0.15f);
				matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(wave * 25f * side));
			}
			case "Stab" -> {
				matrices.translate(0f, 0f, -wave * 0.45f);
				matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-wave * 20f));
			}
			case "Swank" -> {
				matrices.translate(-wave * 0.2f * side, wave * 0.15f, -wave * 0.2f);
				matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(wave * 45f * side));
				matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-wave * 25f));
			}
			case "Spin" -> {
				matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(progress * 360f * strength * side));
			}
			case "Exhibition" -> {
				matrices.translate(wave * 0.1f * side, -wave * 0.2f, -wave * 0.1f);
				matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(wave * 55f));
			}
			case "Old 1.7" -> {
				// 1.7 held the item lower and swung it with less Z travel
				matrices.translate(0f, -0.08f, 0f);
				matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(wave * 12f * side));
				matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-wave * 8f));
			}
			default -> {
			}
		}
	}
}
