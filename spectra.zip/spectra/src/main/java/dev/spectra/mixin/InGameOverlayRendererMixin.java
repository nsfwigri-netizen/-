package dev.spectra.mixin;

import dev.spectra.Spectra;
import dev.spectra.modules.visual.NoRender;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Kills the big first person fire overlay that eats a third of the screen.
 *
 * This is a SEPARATE render path from fire on entities: entities go through
 * Entity#doesRenderOnFire, while the screen overlay is drawn here. That is why
 * hooking only doesRenderOnFire removed the flames on mobs but left the overlay.
 *
 * 1.21.4 target (verified against yarn 1.21.4+build.8):
 *   private static void renderFireOverlay(MatrixStack matrices, VertexConsumerProvider vertexConsumers)
 */
@Mixin(InGameOverlayRenderer.class)
public class InGameOverlayRendererMixin {
	@Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
	private static void spectra$noFireOverlay(MatrixStack matrices, VertexConsumerProvider vertexConsumers, CallbackInfo ci) {
		NoRender noRender = Spectra.modules().get(NoRender.class);
		if (noRender != null && noRender.shouldHideFire()) {
			ci.cancel();
		}
	}
}
