package dev.spectra.mixin;

import dev.spectra.Spectra;
import dev.spectra.modules.visual.Zoom;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * FOV override for Zoom.
 *
 * NOTE: getFov is private in GameRenderer; if Yarn changes the signature on a
 * mappings bump, fix it here. On 1.21.4 it is:
 *   private float getFov(Camera camera, float tickProgress, boolean changingFov)
 */
@Mixin(GameRenderer.class)
public class GameRendererMixin {
	@Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
	private void spectra$zoom(Camera camera, float tickProgress, boolean changingFov, CallbackInfoReturnable<Float> cir) {
		Zoom zoom = Spectra.modules().get(Zoom.class);
		if (zoom == null || !zoom.isEnabled() || !zoom.isZooming()) return;
		cir.setReturnValue((float) (cir.getReturnValue() / zoom.getCurrentFovScale()));
	}
}
