package dev.spectra.mixin;

import dev.spectra.Spectra;
import dev.spectra.modules.visual.NoRender;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * doesRenderOnFire() is checked both by the entity renderer and by the HUD before
 * drawing the first person fire overlay, so one hook removes both.
 * This is visual only: you still burn and still take damage.
 */
@Mixin(Entity.class)
public class EntityFireMixin {
	@Inject(method = "doesRenderOnFire", at = @At("HEAD"), cancellable = true)
	private void spectra$noFire(CallbackInfoReturnable<Boolean> cir) {
		NoRender noRender = Spectra.modules().get(NoRender.class);
		if (noRender != null && noRender.shouldHideFire()) {
			cir.setReturnValue(false);
		}
	}
}
