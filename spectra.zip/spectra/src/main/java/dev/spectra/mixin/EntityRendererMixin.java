package dev.spectra.mixin;

import dev.spectra.Spectra;
import dev.spectra.modules.visual.NoRender;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Single hook that kills entity rendering for every entity type.
 *
 * shouldRender is the cheapest and most version-stable place to cancel: it runs
 * before the render state is even built, so hidden entities cost almost nothing.
 * Cancelling inside render() instead would still pay for state extraction.
 */
@Mixin(EntityRenderer.class)
public class EntityRendererMixin {
	@Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
	private void spectra$noRender(Entity entity, Frustum frustum, double x, double y, double z,
	                              CallbackInfoReturnable<Boolean> cir) {
		NoRender noRender = Spectra.modules().get(NoRender.class);
		if (noRender != null && noRender.shouldHideEntity(entity)) {
			cir.setReturnValue(false);
		}
	}
}
