package dev.spectra.mixin;

import dev.spectra.Spectra;
import dev.spectra.modules.utility.LockSlot;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Cancels inventory clicks that would move an item out of a locked hotbar slot. */
@Mixin(HandledScreen.class)
public class HandledScreenMixin {
	@Inject(method = "onMouseClick(Lnet/minecraft/screen/slot/Slot;IILnet/minecraft/screen/slot/SlotActionType;)V",
			at = @At("HEAD"), cancellable = true)
	private void spectra$lockSlot(Slot slot, int slotId, int button, SlotActionType actionType, CallbackInfo ci) {
		LockSlot lockSlot = Spectra.modules().get(LockSlot.class);
		if (lockSlot == null || !lockSlot.isEnabled() || slot == null) return;

		// Player inventory hotbar occupies slots 36..44 in the player screen.
		int index = slot.getIndex();
		if (index >= 0 && index <= 8 && lockSlot.isLocked(index)) {
			ci.cancel();
		}
	}
}
