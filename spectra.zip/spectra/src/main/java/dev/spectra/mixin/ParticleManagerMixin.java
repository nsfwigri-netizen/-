package dev.spectra.mixin;

import dev.spectra.Spectra;
import dev.spectra.modules.visual.NoRender;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Drops particles at the point they are queued, so they never tick or render.
 * Cancelling here (not at render time) is what actually saves frames.
 */
@Mixin(ParticleManager.class)
public class ParticleManagerMixin {
	@Inject(method = "addParticle(Lnet/minecraft/client/particle/Particle;)V", at = @At("HEAD"), cancellable = true)
	private void spectra$noParticles(Particle particle, CallbackInfo ci) {
		NoRender noRender = Spectra.modules().get(NoRender.class);
		if (noRender != null && noRender.shouldHideParticle(particle)) {
			ci.cancel();
		}
	}
}
