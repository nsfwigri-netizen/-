package dev.spectra;

import dev.spectra.config.ConfigManager;
import dev.spectra.module.ModuleManager;
import dev.spectra.ui.SpectraScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Spectra implements ClientModInitializer {
	public static final String MOD_ID = "spectra";
	public static final String NAME = "Spectra";
	public static final Logger LOG = LoggerFactory.getLogger(NAME);

	private static ModuleManager moduleManager;
	private static ConfigManager configManager;

	private static KeyBinding openMenu;

	@Override
	public void onInitializeClient() {
		moduleManager = new ModuleManager();
		moduleManager.registerAll();

		configManager = new ConfigManager(moduleManager);
		configManager.load();

		openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.spectra.menu",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_RIGHT_SHIFT,
				"key.categories.spectra"
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openMenu.wasPressed()) {
				client.setScreen(new SpectraScreen());
			}
			moduleManager.onTick();
		});

		LOG.info("{} initialized with {} modules", NAME, moduleManager.getModules().size());
	}

	public static ModuleManager modules() {
		return moduleManager;
	}

	public static ConfigManager config() {
		return configManager;
	}
}
