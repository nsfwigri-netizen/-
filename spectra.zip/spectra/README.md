# Spectra

Visual and utility module client for **Minecraft 1.21.4 / Fabric**, built to run on Android
(ZalithLauncher + MobileGlues renderer).

## Stack

| | |
| --- | --- |
| Minecraft | 1.21.4 |
| Yarn | 1.21.4+build.8 |
| Loader | 0.16.10 |
| Fabric API | 0.119.4+1.21.4 |
| Loom | 1.9-SNAPSHOT |
| Gradle | 8.12 |
| Java | 21 |

Client-only mod. MobileGlues is **not** a dependency, it is just the renderer the client runs on.

## Build

Push to `main` and GitHub Actions builds the jar (`.github/workflows/build.yml`).
The jar lands in the run's artifacts as `spectra-jar`.

Locally, if you ever have a desktop again:

```
gradle build
```

## Opening the menu

Default bind: **Right Shift**. Rebind it in vanilla Controls under the `Spectra` category.

## Architecture

```
dev.spectra
├── Spectra.java            entrypoint, keybind, tick loop
├── module/
│   ├── Category.java       VISUALS / UTILITY / CLIENT
│   ├── Module.java         base class, declares its own settings
│   └── ModuleManager.java  registry + per-tick dispatch + toggle binds
├── setting/                Boolean / Number / Mode / Color / Keybind
├── config/ConfigManager    JSON profiles in config/spectra/<profile>.json
├── ui/SpectraScreen        3-panel GUI, search, tooltip, nested settings
├── modules/visual/         Zoom (sample)
├── modules/utility/        Lock Slot (sample)
└── mixin/                  GameRendererMixin, HandledScreenMixin
```

### Adding a module

```java
public class ItemPhysics extends Module {
    public final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.5, 2.0, 0.1));
    public final BooleanSetting flatOnGround = add(new BooleanSetting("Flat on ground", true));

    public ItemPhysics() {
        super("Item Physics", "Dropped items lie flat and bounce.", Category.VISUALS);
    }
}
```

Then one line in `ModuleManager.registerAll()`. The GUI renders the settings automatically —
no per-module UI code.

## Module roadmap (29)

**Visuals (15)** — Swing Animation, View Model, Item Physics, Item Light, Shader Sky,
Shader Hands, World Particles, Mouse Particles, Hit Color, Hit Particles, HitBox Customizer,
Pet, Zoom ✅, NoRender

**Utility (9)** — HitSound, KillSound, Low Armor Notify, Item Pickup Logger, Lock Slot ✅,
Shift Tap, Streamer Mode, Name Protect, Item Scroller

**Client (5)** — Configs ✅, Theme, Gui Size, Friends, GPS

## Platform notes

- **Item Light** forces chunk rebuilds. Ship it with the cheapest mode as default or it will
  tank FPS on mobile.
- **Shaders**: MobileGlues converts desktop GLSL to GLSL ES, but you must declare
  `precision highp float;` and `precision highp int;` yourself.
- **HUD**: `HudRenderCallback` is deprecated on 1.21.4. Use the newer Hud API for any HUD module.
- **Sprint modules**: press the sprint *keybind* (`setPressed`), never `setSprinting()` —
  that desyncs from the server and sticks (see MC-225790).
