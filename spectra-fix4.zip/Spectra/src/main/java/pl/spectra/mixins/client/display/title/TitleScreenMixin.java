package pl.spectra.mixins.client.display.title;

import com.mojang.blaze3d.platform.GlStateManager;
import java.awt.Color;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_4587;
import net.minecraft.class_7919;
import net.minecraft.class_8020;
import net.minecraft.class_8519;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.spectra.utils.display.shape.ShapeProperties;
import pl.spectra.utils.display.shape.implement.Rectangle;

@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {
   @Unique
   private static final class_8519 FORCE_SPLASH_TEXT = new class_8519("Spectra");
   @Shadow
   private class_8519 field_2586;

   protected TitleScreenMixin(class_2561 title) {
      super(title);
   }

   @Inject(method = "init", at = @At("TAIL"))
   private void spectra$initTitleScreen(CallbackInfo ci) {
      this.field_2586 = FORCE_SPLASH_TEXT;
   }

   @Redirect(
      method = "method_25394",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/class_442;method_57728(Lnet/minecraft/class_332;F)V"),
      remap = false
   )
   private void spectra$blackInsteadOfPanorama(class_442 screen, class_332 context, float delta) {
      GlStateManager._clearColor(0.0F, 0.0F, 0.0F, 1.0F);
      GlStateManager._clear(16384);
      class_4587 matrix = context.method_51448();
      int screenW = class_310.method_1551().method_22683().method_4486();
      int screenH = class_310.method_1551().method_22683().method_4502();
      new Rectangle().render(
         ShapeProperties.create(matrix, 0.0, 0.0, (double)screenW, (double)screenH)
            .color(
               new Color(28, 16, 58).getRGB(),
               new Color(2, 2, 6).getRGB(),
               new Color(16, 30, 64).getRGB(),
               new Color(2, 2, 6).getRGB()
            )
            .build()
      );
   }

   @Redirect(
      method = "method_25394",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/class_8020;method_48209(Lnet/minecraft/class_332;IF)V"),
      remap = false
   )
   private void spectra$noLogo(class_8020 logo, class_332 context, int width, float alpha) {
   }

   @Redirect(
      method = "method_25394",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/class_8519;method_51453(Lnet/minecraft/class_332;ILnet/minecraft/class_327;I)V"),
      remap = false
   )
   private void spectra$noSplash(class_8519 splash, class_332 context, int centerX, class_327 font, int color) {
   }

   @Redirect(
      method = "method_25394",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/class_332;method_25303(Lnet/minecraft/class_327;Ljava/lang/String;III)I"),
      remap = false
   )
   private int spectra$noVersion(class_332 context, class_327 font, String text, int x, int y, int color) {
      return 0;
   }
}
