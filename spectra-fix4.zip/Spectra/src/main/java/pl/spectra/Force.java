package pl.spectra;

import java.io.File;
import java.util.Set;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_310;
import pl.spectra.commands.CommandDispatcher;
import pl.spectra.commands.manager.CommandRepository;
import pl.spectra.common.repository.autocommand.AutoCommandRepository;
import pl.spectra.common.repository.macro.MacroRepository;
import pl.spectra.common.repository.way.WayRepository;
import pl.spectra.display.screens.clickgui.MenuScreen;
import pl.spectra.features.module.ModuleProvider;
import pl.spectra.features.module.ModuleRepository;
import pl.spectra.features.module.ModuleSwitcher;
import pl.spectra.main.client.ClientInfo;
import pl.spectra.main.client.ClientInfoProvider;
import pl.spectra.main.listener.ListenerRepository;
import pl.spectra.utils.client.logs.Logger;
import pl.spectra.utils.client.managers.api.draggable.DraggableRepository;
import pl.spectra.utils.client.managers.event.EventManager;
import pl.spectra.utils.client.managers.file.DirectoryCreator;
import pl.spectra.utils.client.managers.file.FileController;
import pl.spectra.utils.client.managers.file.FileRepository;
import pl.spectra.utils.client.managers.file.exception.FileProcessingException;
import pl.spectra.utils.client.sound.SoundManager;
import pl.spectra.utils.connection.tps.TPSCalculate;
import pl.spectra.utils.display.scissor.ScissorAssist;
import pl.spectra.utils.update.ClientVersion;

public class Force implements ModInitializer {
   static Force instance;
   private EventManager eventManager = new EventManager();
   private ModuleRepository moduleRepository;
   private ModuleSwitcher moduleSwitcher;
   private CommandRepository commandRepository;
   private CommandDispatcher commandDispatcher;
   private MacroRepository macroRepository = new MacroRepository(this.eventManager);
   private WayRepository wayRepository = new WayRepository(this.eventManager);
   private AutoCommandRepository autoCommandRepository = new AutoCommandRepository(this.eventManager);
   private ModuleProvider moduleProvider;
   private DraggableRepository draggableRepository;
   private FileRepository fileRepository;
   private FileController fileController;
   private ScissorAssist scissorManager = new ScissorAssist();
   private ClientInfoProvider clientInfoProvider;
   private ListenerRepository listenerRepository;
   private TPSCalculate tpsCalculate;
   private boolean initialized;

   public void onInitialize() {
      instance = this;
      this.initClientInfoProvider();
      this.initModules();
      this.initDraggable();
      this.initFileManager();
      this.initCommands();
      this.initListeners();
      SoundManager.init();
      MenuScreen menuScreen = new MenuScreen();
      menuScreen.initialize();
      this.initialized = true;
   }

   private void initDraggable() {
      this.draggableRepository = new DraggableRepository();
      this.draggableRepository.setup();
   }

   private void initModules() {
      this.moduleRepository = new ModuleRepository();
      this.moduleRepository.setup();
      this.moduleProvider = new ModuleProvider(this.moduleRepository.modules());
      this.moduleSwitcher = new ModuleSwitcher(this.moduleRepository.modules(), this.eventManager);
   }

   private void initCommands() {
      this.commandRepository = new CommandRepository();
      this.commandDispatcher = new CommandDispatcher(this.eventManager);
   }

   private void initClientInfoProvider() {
      File clientDirectory = new File(class_310.method_1551().field_1697, "Spectra");
      File filesDirectory = new File(clientDirectory, "Files");
      this.clientInfoProvider = new ClientInfo(ClientVersion.displayName(), clientDirectory, filesDirectory);
   }

   private void initFileManager() {
      DirectoryCreator directoryCreator = new DirectoryCreator();
      directoryCreator.createDirectories(this.clientInfoProvider.clientDir(), this.clientInfoProvider.filesDir());
      this.cleanupLegacyArtifacts(this.clientInfoProvider.clientDir(), this.clientInfoProvider.filesDir());
      File customDir = new File(this.clientInfoProvider.clientDir(), "Custom");
      if (!customDir.exists()) {
         customDir.mkdirs();
      }

      new File(customDir, "Capes").mkdirs();

      this.fileRepository = new FileRepository();
      this.fileRepository.setup(this);
      this.fileController = new FileController(this.fileRepository.getClientFiles(), this.clientInfoProvider.filesDir());

      try {
         this.fileController.loadFiles();
      } catch (FileProcessingException var5) {
         Logger.error("Failed to load files: " + var5.getMessage());
      }

      try {
         this.fileController.saveFiles();
      } catch (FileProcessingException var4) {
         Logger.error("Failed to normalize files: " + var4.getMessage());
      }
   }

   private void initListeners() {
      this.listenerRepository = new ListenerRepository();
      this.listenerRepository.setup();
      this.tpsCalculate = new TPSCalculate();
   }

   private void cleanupLegacyArtifacts(File clientDirectory, File filesDirectory) {
      this.deleteUnexpectedChildren(clientDirectory, Set.of("Custom", "Files"), Set.of());
      this.deleteUnexpectedChildren(filesDirectory, Set.of(), Set.of("AutoCfg.json", "Friends.json", "Macro.json", "Prefix.json", "Way.json"));
   }

   private void deleteRecursively(File file) {
      if (file != null && file.exists()) {
         if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
               for (File child : children) {
                  this.deleteRecursively(child);
               }
            }
         }

         if (!file.delete()) {
            Logger.warn("Failed to delete legacy artifact: " + file.getAbsolutePath());
         }
      }
   }

   private void deleteUnexpectedChildren(File directory, Set<String> allowedDirectories, Set<String> allowedFiles) {
      File[] children = directory.listFiles();
      if (children != null) {
         for (File child : children) {
            if (child.isDirectory()) {
               if (!allowedDirectories.contains(child.getName())) {
                  this.deleteRecursively(child);
               }
            } else if (!allowedFiles.contains(child.getName())) {
               this.deleteRecursively(child);
            }
         }
      }
   }

   public EventManager getEventManager() { return this.eventManager; }
   public ModuleRepository getModuleRepository() { return this.moduleRepository; }
   public ModuleSwitcher getModuleSwitcher() { return this.moduleSwitcher; }
   public CommandRepository getCommandRepository() { return this.commandRepository; }
   public CommandDispatcher getCommandDispatcher() { return this.commandDispatcher; }
   public MacroRepository getMacroRepository() { return this.macroRepository; }
   public WayRepository getWayRepository() { return this.wayRepository; }
   public AutoCommandRepository getAutoCommandRepository() { return this.autoCommandRepository; }
   public ModuleProvider getModuleProvider() { return this.moduleProvider; }
   public DraggableRepository getDraggableRepository() { return this.draggableRepository; }
   public FileRepository getFileRepository() { return this.fileRepository; }
   public FileController getFileController() { return this.fileController; }
   public ScissorAssist getScissorManager() { return this.scissorManager; }
   public ClientInfoProvider getClientInfoProvider() { return this.clientInfoProvider; }
   public ListenerRepository getListenerRepository() { return this.listenerRepository; }
   public TPSCalculate getTpsCalculate() { return this.tpsCalculate; }
   public boolean isInitialized() { return this.initialized; }

   public void setEventManager(EventManager eventManager) { this.eventManager = eventManager; }
   public void setModuleRepository(ModuleRepository moduleRepository) { this.moduleRepository = moduleRepository; }
   public void setModuleSwitcher(ModuleSwitcher moduleSwitcher) { this.moduleSwitcher = moduleSwitcher; }
   public void setCommandRepository(CommandRepository commandRepository) { this.commandRepository = commandRepository; }
   public void setCommandDispatcher(CommandDispatcher commandDispatcher) { this.commandDispatcher = commandDispatcher; }
   public void setMacroRepository(MacroRepository macroRepository) { this.macroRepository = macroRepository; }
   public void setWayRepository(WayRepository wayRepository) { this.wayRepository = wayRepository; }
   public void setModuleProvider(ModuleProvider moduleProvider) { this.moduleProvider = moduleProvider; }
   public void setDraggableRepository(DraggableRepository draggableRepository) { this.draggableRepository = draggableRepository; }
   public void setFileRepository(FileRepository fileRepository) { this.fileRepository = fileRepository; }
   public void setFileController(FileController fileController) { this.fileController = fileController; }
   public void setScissorManager(ScissorAssist scissorManager) { this.scissorManager = scissorManager; }
   public void setClientInfoProvider(ClientInfoProvider clientInfoProvider) { this.clientInfoProvider = clientInfoProvider; }
   public void setListenerRepository(ListenerRepository listenerRepository) { this.listenerRepository = listenerRepository; }
   public void setTpsCalculate(TPSCalculate tpsCalculate) { this.tpsCalculate = tpsCalculate; }
   public void setInitialized(boolean initialized) { this.initialized = initialized; }

   public static Force getInstance() { return instance; }
}
