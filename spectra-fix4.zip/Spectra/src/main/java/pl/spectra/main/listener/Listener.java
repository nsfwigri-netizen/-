package pl.spectra.main.listener;

import pl.spectra.utils.display.interfaces.QuickLogger;

public interface Listener extends QuickLogger {
}
