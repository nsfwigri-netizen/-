package pl.spectra.main.listener.impl;

import net.minecraft.class_1309;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import pl.spectra.Force;
import pl.spectra.common.repository.friend.FriendUtils;
import pl.spectra.events.packet.PacketEvent;
import pl.spectra.events.player.AttackEvent;
import pl.spectra.events.player.TickEvent;
import pl.spectra.main.listener.Listener;
import pl.spectra.utils.client.managers.api.draggable.AbstractDraggable;
import pl.spectra.utils.client.managers.event.EventHandler;
import pl.spectra.utils.client.packet.network.Network;
import pl.spectra.utils.client.target.TargetTracker;

public class EventListener implements Listener {
   public static boolean serverSprint;
   public static int selectedSlot;

   @EventHandler
   public void onTick(TickEvent e) {
      Network.tick();
      TargetTracker.tick();
      Force.getInstance().getDraggableRepository().draggable().forEach(AbstractDraggable::tick);
   }

   @EventHandler
   public void onPacket(PacketEvent e) {
      switch (e.getPacket()) {
         case class_2848 command:
            serverSprint = switch (command.method_12365()) {
               case field_12981 -> true;
               case field_12985 -> false;
               default -> serverSprint;
            };
            break;
         case class_2868 slot:
            selectedSlot = slot.method_12442();
            break;
         default:
      }

      Network.packet(e);
      Force.getInstance().getDraggableRepository().draggable().forEach(drag -> drag.packet(e));
   }

   @EventHandler
   public void onAttack(AttackEvent e) {
      if (FriendUtils.isFriend(e.getEntity())) {
         e.setCancelled(true);
      } else {
         if (e.getEntity() instanceof class_1309 livingEntity) {
            TargetTracker.setTarget(livingEntity);
         }
      }
   }
}
