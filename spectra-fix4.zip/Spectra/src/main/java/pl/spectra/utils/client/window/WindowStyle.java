package pl.spectra.utils.client.window;

import java.io.InputStream;
import net.minecraft.class_1011;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.glfw.GLFWImage.Buffer;
import org.lwjgl.system.MemoryUtil;

/**
 * Spectra: JNA / WinAPI вырезаны — клиент собирается под Android/Linux.
 * Осталась только установка иконки окна через GLFW, и то безопасно-no-op при любой ошибке.
 */
public class WindowStyle {
   private WindowStyle() {
   }

   public static void setMinecraftIcon(long windowHandle) {
      if (windowHandle == 0L) {
         return;
      }

      try (InputStream stream = WindowStyle.class.getClassLoader().getResourceAsStream("assets/minecraft/icon.png")) {
         if (stream == null) {
            return;
         }

         try (class_1011 image = class_1011.method_4309(stream)) {
            Buffer icons = GLFWImage.malloc(1);

            try {
               icons.position(0);
               icons.width(image.method_4307());
               icons.height(image.method_4323());
               icons.pixels(MemoryUtil.memByteBuffer(image.field_4988, image.method_4307() * image.method_4323() * 4));
               GLFW.glfwSetWindowIcon(windowHandle, icons);
            } finally {
               icons.free();
            }
         }
      } catch (Throwable ignored) {
      }
   }
}
