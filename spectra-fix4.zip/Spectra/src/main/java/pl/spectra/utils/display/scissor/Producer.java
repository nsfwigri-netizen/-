package pl.spectra.utils.display.scissor;

public interface Producer<T> {
   T create();
}
