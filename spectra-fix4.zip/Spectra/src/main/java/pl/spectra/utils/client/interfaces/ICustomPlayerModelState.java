package pl.spectra.utils.client.interfaces;

// реализуется миксином на PlayerEntityRenderState (class_10055) — переносит флаг
// "рисовать кастомную модель" из состояния рендера игрока в рендерер модели/брони.
public interface ICustomPlayerModelState {
   boolean spectra$hasCustomModel();

   String spectra$getCustomModel();

   void spectra$setCustomModel(boolean enabled, String model);
}
