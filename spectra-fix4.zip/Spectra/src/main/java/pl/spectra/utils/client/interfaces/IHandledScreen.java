package pl.spectra.utils.client.interfaces;

import net.minecraft.class_1735;

public interface IHandledScreen {
   class_1735 spectra$focusedSlot();
}
