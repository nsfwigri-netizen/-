package pl.spectra.utils.display.font.glyph;

public record Glyph(int u, int v, int width, int height, char value, GlyphMap owner) {
}
