package pl.spectra.utils.client.managers.api.command.registry;

import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class Registry<V> {
   private final Deque<V> _entries = new LinkedList<>();
   private final Set<V> registered = new HashSet<>();
   public final Collection<V> entries = Collections.unmodifiableCollection(this._entries);

   public boolean registered(V entry) {
      return this.registered.contains(entry);
   }

   public void register(V entry) {
      if (!this.registered(entry)) {
         this._entries.addFirst(entry);
         this.registered.add(entry);
      }
   }

   public void unregister(V entry) {
      if (this.registered(entry)) {
         this._entries.remove(entry);
         this.registered.remove(entry);
      }
   }

   public Iterator<V> iterator() {
      return this._entries.iterator();
   }

   public Iterator<V> descendingIterator() {
      return this._entries.descendingIterator();
   }

   public Stream<V> stream() {
      return this._entries.stream();
   }

   public Stream<V> descendingStream() {
      Spliterator<V> spliterator = Spliterators.spliterator(this.descendingIterator(), (long)this._entries.size(), 16448);
      return StreamSupport.stream(spliterator, false);
   }
}
