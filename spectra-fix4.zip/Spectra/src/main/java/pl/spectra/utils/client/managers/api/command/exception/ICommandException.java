package pl.spectra.utils.client.managers.api.command.exception;

import java.util.List;
import net.minecraft.class_124;
import pl.spectra.utils.client.managers.api.command.ICommand;
import pl.spectra.utils.client.managers.api.command.argument.ICommandArgument;
import pl.spectra.utils.display.interfaces.QuickLogger;

public interface ICommandException extends QuickLogger {
   String getMessage();

   default void handle(ICommand command, List<ICommandArgument> args) {
      this.logDirect(this.getMessage(), class_124.field_1061);
   }
}
