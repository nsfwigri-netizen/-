package pl.spectra.utils.math.script;

@FunctionalInterface
public interface ScriptAction {
   void perform();
}
