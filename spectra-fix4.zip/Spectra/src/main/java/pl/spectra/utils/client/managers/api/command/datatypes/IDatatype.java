package pl.spectra.utils.client.managers.api.command.datatypes;

import java.util.stream.Stream;
import pl.spectra.utils.client.managers.api.command.exception.CommandException;
import pl.spectra.utils.display.interfaces.QuickImports;

public interface IDatatype extends QuickImports {
   Stream<String> tabComplete(IDatatypeContext var1) throws CommandException;
}
