package pl.spectra.utils.client.managers.event.events;

public interface Event {
}
