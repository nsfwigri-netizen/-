package pl.spectra.utils.display.font.entry;

import pl.spectra.utils.display.font.glyph.Glyph;

public record DrawEntry(float atX, float atY, int color, Glyph toDraw) {
}
