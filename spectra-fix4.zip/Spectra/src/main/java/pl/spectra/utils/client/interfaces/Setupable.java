package pl.spectra.utils.client.interfaces;

import pl.spectra.features.module.setting.Setting;

public interface Setupable {
   void setup(Setting... var1);
}
