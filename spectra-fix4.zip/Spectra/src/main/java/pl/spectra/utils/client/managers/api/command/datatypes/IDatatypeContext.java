package pl.spectra.utils.client.managers.api.command.datatypes;

import pl.spectra.utils.client.managers.api.command.argument.IArgConsumer;

public interface IDatatypeContext {
   IArgConsumer getConsumer();
}
