package pl.spectra.utils.client.managers.event.events;

public interface Typed {
   byte getType();
}
