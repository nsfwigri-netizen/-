package pl.spectra.utils.display.shape;

public interface Shape {
   void render(ShapeProperties var1);
}
