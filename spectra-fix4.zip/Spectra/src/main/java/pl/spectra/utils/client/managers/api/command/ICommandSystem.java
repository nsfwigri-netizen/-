package pl.spectra.utils.client.managers.api.command;

import pl.spectra.utils.client.managers.api.command.argparser.IArgParserManager;

public interface ICommandSystem {
   IArgParserManager getParserManager();
}
