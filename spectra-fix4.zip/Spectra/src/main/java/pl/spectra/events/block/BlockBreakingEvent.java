package pl.spectra.events.block;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import pl.spectra.utils.client.managers.event.events.Event;

public record BlockBreakingEvent(class_2338 blockPos, class_2350 direction) implements Event {
}
