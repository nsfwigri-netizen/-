package pl.spectra.events.block;

import net.minecraft.class_2338;
import pl.spectra.utils.client.managers.event.events.Event;

public record BreakBlockEvent(class_2338 blockPos) implements Event {
}
