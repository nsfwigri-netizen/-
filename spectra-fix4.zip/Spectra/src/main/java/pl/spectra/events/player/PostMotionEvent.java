package pl.spectra.events.player;

import pl.spectra.utils.client.managers.event.events.callables.EventCancellable;

public class PostMotionEvent extends EventCancellable {
}
