package pl.spectra.events.render;

import pl.spectra.utils.client.managers.event.events.Event;

public class WorldLoadEvent implements Event {
}
