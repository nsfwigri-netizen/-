package pl.spectra.events.player;

import pl.spectra.utils.client.managers.event.events.Event;

public class KeepSprintEvent implements Event {
}
