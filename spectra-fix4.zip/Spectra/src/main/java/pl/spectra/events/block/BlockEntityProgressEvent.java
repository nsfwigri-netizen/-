package pl.spectra.events.block;

import net.minecraft.class_2586;
import pl.spectra.utils.client.managers.event.events.Event;

public record BlockEntityProgressEvent(class_2586 blockEntity, BlockEntityProgressEvent.Type type) implements Event {
   public static enum Type {
      ADD,
      REMOVE;
   }
}
