package pl.spectra.features.module;

import java.util.ArrayList;
import java.util.List;

import pl.spectra.features.impl.movement.AutoSprint;
import pl.spectra.features.impl.movement.CardChecker;
import pl.spectra.features.impl.movement.ClickPearl;
import pl.spectra.features.impl.movement.CrystalOptimizer;
import pl.spectra.features.impl.movement.Cooldowns;
import pl.spectra.features.impl.movement.ItemHighlighter;
import pl.spectra.features.impl.movement.ItemScroller;
import pl.spectra.features.impl.movement.ItemSwap;
import pl.spectra.features.impl.movement.TapeMouse;
import pl.spectra.features.impl.movement.Tracker;
import pl.spectra.features.impl.player.FreeLook;
import pl.spectra.features.impl.render.AspectRatio;
import pl.spectra.features.impl.render.BetterMinecraft;
import pl.spectra.features.impl.render.BlockOverlay;
import pl.spectra.features.impl.render.Camera;
import pl.spectra.features.impl.render.ClientColor;
import pl.spectra.features.impl.render.Cosmetic;
import pl.spectra.features.impl.render.CrossHair;
import pl.spectra.features.impl.render.HandShader;
import pl.spectra.features.impl.render.Interface;
import pl.spectra.features.impl.render.MotionBlur;
import pl.spectra.features.impl.render.NoRender;
import pl.spectra.features.impl.render.Predictions;
import pl.spectra.features.impl.render.SaturationBar;
import pl.spectra.features.impl.render.SelfNametag;
import pl.spectra.features.impl.render.SwingAnimation;
import pl.spectra.features.impl.render.ViewModel;
import pl.spectra.features.impl.render.WaypointESP;
import pl.spectra.features.impl.render.WorldTweaks;

public class ModuleRepository {
   private final List<Module> modules = new ArrayList<>();

   public void setup() {
      this.register(
         new AutoSprint(),
         new CardChecker(),
         new ClickPearl(),
         new CrystalOptimizer(),
         new Cooldowns(),
         new ItemHighlighter(),
         new ItemScroller(),
         new FreeLook(),
         new BetterMinecraft(),
         new AspectRatio(),
         new Interface(),
         new MotionBlur(),
         new Camera(),
         new SwingAnimation(),
         new ViewModel(),
         new BlockOverlay(),
         new WorldTweaks(),
         new NoRender(),
         new CrossHair(),
         new WaypointESP(),
         new HandShader(),
         new Cosmetic(),
         new ClientColor(),
         new TapeMouse(),
         new ItemSwap(),
         new Predictions(),
         new SaturationBar(),
         new Tracker(),
         new SelfNametag()
      );
   }

   public void register(Module... module) {
      this.modules.addAll(List.of(module));
   }

   public List<Module> modules() {
      return this.modules;
   }
}
