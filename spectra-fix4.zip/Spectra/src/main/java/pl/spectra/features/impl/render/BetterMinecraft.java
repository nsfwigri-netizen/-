package pl.spectra.features.impl.render;

import pl.spectra.features.module.Module;
import pl.spectra.features.module.ModuleCategory;
import pl.spectra.features.module.setting.implement.BooleanSetting;
import pl.spectra.utils.client.Instance;

public class BetterMinecraft extends Module {
   private final BooleanSetting betterButton = new BooleanSetting("Кастомные клавиши", "Использовать кастомные клавиши").setValue(true);

   public static BetterMinecraft getInstance() {
      return Instance.get(BetterMinecraft.class);
   }

   public BetterMinecraft() {
      super("BetterMinecraft", "Better Minecraft", ModuleCategory.RENDER);
      this.setup(this.betterButton);
   }

   public BooleanSetting getBetterButton() {
      return this.betterButton;
   }
}
