package pl.spectra.features.impl.render;

import pl.spectra.features.module.Module;
import pl.spectra.features.module.ModuleCategory;
import pl.spectra.utils.client.Instance;

// Показывает собственный никнейм над игроком от третьего лица.
// Логику отрисовки лейбла включает LivingEntityRendererMixin (method_4055 = hasLabel).
public class SelfNametag extends Module {
   public static SelfNametag getInstance() {
      return Instance.get(SelfNametag.class);
   }

   public SelfNametag() {
      super("SelfNametag", "Self Nametag", ModuleCategory.RENDER);
   }
}
