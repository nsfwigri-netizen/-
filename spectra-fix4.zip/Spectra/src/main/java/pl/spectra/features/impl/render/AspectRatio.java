package pl.spectra.features.impl.render;

import pl.spectra.events.render.AspectRatioEvent;
import pl.spectra.features.module.Module;
import pl.spectra.features.module.ModuleCategory;
import pl.spectra.features.module.setting.implement.SliderSettings;
import pl.spectra.utils.client.managers.event.EventHandler;

public class AspectRatio extends Module {
   private final SliderSettings ratioSetting = new SliderSettings("Соотношение", "Соотношение сторон экрана").setValue(1.0F).range(0.1F, 2.0F);

   public AspectRatio() {
      super("AspectRatio", "Aspect Ratio", ModuleCategory.RENDER);
      this.setup(this.ratioSetting);
   }

   @EventHandler
   public void onAspectRatio(AspectRatioEvent e) {
      e.setRatio(this.ratioSetting.getValue());
      e.cancel();
   }
}
