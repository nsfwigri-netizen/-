package pl.spectra.features.impl.render;

import pl.spectra.features.module.Module;
import pl.spectra.features.module.ModuleCategory;
import pl.spectra.utils.client.Instance;

public final class SaturationBar extends Module {
   public SaturationBar() {
      super("SaturationBar", "Saturation Bar", ModuleCategory.RENDER);
   }

   public static SaturationBar getInstance() {
      return Instance.get(SaturationBar.class);
   }
}
