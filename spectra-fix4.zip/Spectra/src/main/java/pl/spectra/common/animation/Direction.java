package pl.spectra.common.animation;

public enum Direction {
   FORWARDS,
   BACKWARDS;
}
