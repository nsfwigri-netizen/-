package pl.spectra.common.repository.macro;

public record Macro(String name, String message, int key) {
}
