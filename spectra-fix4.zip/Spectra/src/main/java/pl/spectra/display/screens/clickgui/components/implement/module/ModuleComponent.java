package pl.spectra.display.screens.clickgui.components.implement.module;

import java.awt.Color;
import java.util.Objects;
import net.minecraft.class_310;
import net.minecraft.class_332;
import pl.spectra.display.screens.clickgui.MenuScreen;
import pl.spectra.display.screens.clickgui.components.AbstractComponent;
import pl.spectra.features.module.Module;
import pl.spectra.utils.client.sound.SoundManager;
import pl.spectra.utils.display.color.ColorAssist;
import pl.spectra.utils.display.font.Fonts;
import pl.spectra.utils.display.shape.ShapeProperties;
import pl.spectra.utils.math.calc.Calculate;

public class ModuleComponent extends AbstractComponent {
   public static boolean anyBinding = false;
   private final Module module;
   private boolean binding;

   public ModuleComponent(Module module) {
      this.module = module;
   }

   @Override
   public void render(class_332 context, int mouseX, int mouseY, float delta) {
      this.height = 26.0F;
      boolean hovered = Calculate.isHovered(mouseX, mouseY, this.x, this.y, this.width, this.height);
      net.minecraft.class_4587 matrix = context.method_51448();

      // Hover
      if (hovered) {
         rectangle.render(
            ShapeProperties.create(matrix, this.x, this.y, this.width, this.height)
               .color(new Color(255, 255, 255, 12).getRGB())
               .build()
         );
      }

      boolean enabled = this.module.isState();
      boolean hasSettings = !this.module.settings().isEmpty();

      // Левая полоска акцентного цвета когда включён
      if (enabled) {
         rectangle.render(
            ShapeProperties.create(matrix, this.x, this.y + 5.0F, 2.5F, this.height - 10.0F)
               .round(1.5F)
               .color(ColorAssist.colorForRectsCustom$())
               .build()
         );
      }

      // Название модуля
      String displayName = this.binding ? "Нажмите клавишу..." : this.module.getVisibleName();
      int nameAlpha = enabled ? 235 : 140;
      float nameX = this.x + (enabled ? 11.0F : 8.0F);
      Fonts.getSize(14, Fonts.Type.DEFAULT).drawString(
         matrix, displayName, nameX, this.y + 7.0F, new Color(255, 255, 255, nameAlpha).getRGB()
      );

      // Стрелка ">" справа — только если есть настройки
      if (hasSettings && !this.binding) {
         int arrowAlpha = hovered ? 180 : 90;
         Fonts.getSize(13, Fonts.Type.DEFAULT).drawString(
            matrix, ">", this.x + this.width - 13.0F, this.y + 7.5F,
            new Color(255, 255, 255, arrowAlpha).getRGB()
         );
      }

      // Нижний разделитель
      rectangle.render(
         ShapeProperties.create(matrix, this.x, this.y + this.height - 0.5F, this.width, 0.5F)
            .color(new Color(255, 255, 255, 10).getRGB())
            .build()
      );
   }

   @Override
   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (!Calculate.isHovered(mouseX, mouseY, this.x, this.y, this.width, this.height)) {
         return false;
      }

      // В режиме биндинга любая кнопка мыши устанавливает бинд (кроме средней — отмена)
      if (this.binding) {
         if (button == 2) {
            this.binding = false;
            anyBinding = false;
         } else {
            this.module.setKey(button);
            this.binding = false;
            anyBinding = false;
            SoundManager.playSound(SoundManager.ENABLE_MODULE, 1.0F, 1.0F);
         }
         return true;
      }

      if (button == 2) {
         // Средняя кнопка → режим биндинга
         this.binding = true;
         anyBinding = true;
         return true;
      }

      if (button == 0) {
         boolean hasSettings = !this.module.settings().isEmpty();
         // Клик по зоне стрелки (правые 24px) → открыть настройки
         if (hasSettings && mouseX >= this.x + this.width - 24) {
            ModuleSettingsWindow settingsWindow = windowManager.getWindows()
               .stream()
               .filter(w -> w instanceof ModuleSettingsWindow msw && msw.module.equals(this.module))
               .map(ModuleSettingsWindow.class::cast)
               .findFirst()
               .orElseGet(() -> {
                  ModuleSettingsWindow nw = new ModuleSettingsWindow(this.module);
                  windowManager.add(nw);
                  return nw;
               });
            MenuScreen menu = MenuScreen.INSTANCE;
            int screenWidth = class_310.method_1551().method_22683().method_4486();
            float sw = 162.0F;
            float wx = (menu.x + menu.width + 10 + sw <= screenWidth)
               ? menu.x + menu.width + 10
               : Math.max(0, menu.x - sw - 10);
            float wy = Math.max(0, menu.y - 5);
            settingsWindow.position(wx, wy).size(sw, (float) settingsWindow.getComponentHeight());
            return true;
         }
         // Остальная зона строки → включить/выключить модуль
         this.module.switchState();
         SoundManager.playSound(SoundManager.ENABLE_MODULE, 1.0F, 1.0F);
         return true;
      }

      return false;
   }

   @Override
   public boolean isHover(double mouseX, double mouseY) {
      return Calculate.isHovered(mouseX, mouseY, this.x, this.y, this.width, this.height);
   }

   @Override
   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      if (this.binding) {
         if (keyCode == 261) {
            // Delete → снять бинд
            this.module.setKey(-1);
         }
         this.binding = false;
         anyBinding = false;
         SoundManager.playSound(SoundManager.ENABLE_MODULE, 1.0F, 1.0F);
         return true;
      }
      return super.keyPressed(keyCode, scanCode, modifiers);
   }

   public int getComponentHeight() {
      return 26;
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) return true;
      if (o != null && this.getClass() == o.getClass()) {
         ModuleComponent that = (ModuleComponent) o;
         return this.module.equals(that.module);
      }
      return false;
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.module);
   }

   public Module getModule() { return this.module; }
   public boolean isBinding() { return this.binding; }
}
