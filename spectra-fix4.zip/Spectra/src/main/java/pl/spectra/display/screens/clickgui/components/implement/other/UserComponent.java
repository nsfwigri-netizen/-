package pl.spectra.display.screens.clickgui.components.implement.other;

import net.minecraft.class_332;
import pl.spectra.display.screens.clickgui.components.AbstractComponent;

public class UserComponent extends AbstractComponent {
   @Override
   public void render(class_332 context, int mouseX, int mouseY, float delta) {
   }
}
