package pl.spectra.display.screens.clickgui.components.implement.module;

import pl.spectra.features.module.Module;

public class ModuleDescriptions {
   public static String getDescription(Module module) {
      String var1 = module.getName();

      return switch (var1) {
         case "AutoSprint" -> "Автоматически включает бег при движении вперед";
         case "FreeLook" -> "Позволяет осматриваться без смены направления движения";
         case "BetterMinecraft" -> "Добавляет полезные элементы интерфейса";
         case "AspectRatio" -> "Меняет соотношение сторон экрана";
         case "Interface" -> "Настраивает экранные элементы интерфейса";
         case "MotionBlur" -> "Размытие изображения в движении";
         case "Camera" -> "Настраивает поведение и дистанцию камеры";
         case "SwingAnimation" -> "Меняет анимацию взмаха руки";
         case "ViewModel" -> "Меняет положение предметов в руках";
         case "BlockOverlay" -> "Улучшает отображение выбранного блока";
         case "WorldTweaks" -> "Содержит визуальные улучшения мира";
         case "NoRender" -> "Скрывает лишние визуальные эффекты";
         case "CrossHair" -> "Позволяет настроить прицел";
         default -> "Описание модуля отсутствует";
      };
   }
}
