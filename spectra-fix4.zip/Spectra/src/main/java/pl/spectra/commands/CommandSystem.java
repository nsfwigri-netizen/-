package pl.spectra.commands;

import pl.spectra.commands.argparser.ArgParserManager;
import pl.spectra.utils.client.managers.api.command.ICommandSystem;
import pl.spectra.utils.client.managers.api.command.argparser.IArgParserManager;

public enum CommandSystem implements ICommandSystem {
   INSTANCE;

   @Override
   public IArgParserManager getParserManager() {
      return ArgParserManager.INSTANCE;
   }
}
