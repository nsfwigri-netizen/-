package dev.spectra.module;

import dev.spectra.Spectra;
import dev.spectra.modules.client.GuiSize;
import dev.spectra.modules.utility.LockSlot;
import dev.spectra.modules.visual.ItemLight;
import dev.spectra.modules.visual.ItemPhysics;
import dev.spectra.modules.visual.NoRender;
import dev.spectra.modules.visual.SwingAnimation;
import dev.spectra.modules.visual.ViewModel;
import dev.spectra.modules.visual.Zoom;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
	private final List<Module> modules = new ArrayList<>();

	public void registerAll() {
		// Visuals
		register(new NoRender());
		register(new SwingAnimation());
		register(new ViewModel());
		register(new ItemLight());
		register(new ItemPhysics());
		register(new Zoom());

		// Utility
		register(new LockSlot());

		// Client
		register(new GuiSize());
	}

	public void register(Module module) {
		modules.add(module);
	}

	public void onTick() {
		for (Module module : modules) {
			if (module.isEnabled()) {
				module.onTick();
			}
		}
	}

	/**
	 * Static entry point for the raw key hook in KeyboardMixin.
	 *
	 * Mixins run outside the mod's own object graph, so they cannot hold a manager
	 * reference; this resolves the live manager and is a no-op before init.
	 */
	public static void onKeyPressed(int key) {
		ModuleManager manager = Spectra.modules();
		if (manager != null) {
			manager.handleKeyPressed(key);
		}
	}

	public void handleKeyPressed(int key) {
		if (key == -1) return;
		boolean toggled = false;
		for (Module module : modules) {
			if (module.getKeybind() == key) {
				module.toggle();
				toggled = true;
			}
		}
		// persist immediately: a crash or force-close on mobile would otherwise lose the state
		if (toggled && Spectra.config() != null) {
			Spectra.config().save();
		}
	}

	public List<Module> getModules() {
		return modules;
	}

	public List<Module> getModules(Category category) {
		List<Module> result = new ArrayList<>();
		for (Module module : modules) {
			if (module.getCategory() == category) {
				result.add(module);
			}
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	public <T extends Module> T get(Class<T> type) {
		for (Module module : modules) {
			if (type.isInstance(module)) {
				return (T) module;
			}
		}
		return null;
	}

	public boolean isEnabled(Class<? extends Module> type) {
		Module module = get(type);
		return module != null && module.isEnabled();
	}
}
