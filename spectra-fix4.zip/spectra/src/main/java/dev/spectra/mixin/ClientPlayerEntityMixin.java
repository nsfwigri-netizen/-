package dev.spectra.mixin;

import dev.spectra.Spectra;
import dev.spectra.modules.utility.LockSlot;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Blocks the drop key for locked hotbar slots.
 *
 * dropSelectedItem returns a boolean, so the call is cancelled by returning
 * false: that is what vanilla returns when nothing was dropped, which keeps the
 * client from telling the server an item left the inventory.
 */
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {
	@Inject(method = "dropSelectedItem(Z)Z", at = @At("HEAD"), cancellable = true)
	private void spectra$blockDrop(boolean entireStack, CallbackInfoReturnable<Boolean> cir) {
		LockSlot lockSlot = Spectra.modules().get(LockSlot.class);
		if (lockSlot == null || !lockSlot.shouldBlockDrop()) return;

		ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
		// 1.21.4 yarn: PlayerInventory.selectedSlot is a public field, no getter yet
		if (lockSlot.isLocked(player.getInventory().selectedSlot)) {
			cir.setReturnValue(false);
		}
	}
}
