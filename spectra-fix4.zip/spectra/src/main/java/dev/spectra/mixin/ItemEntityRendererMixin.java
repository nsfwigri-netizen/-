package dev.spectra.mixin;

import dev.spectra.Spectra;
import dev.spectra.modules.visual.ItemPhysics;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Lays dropped items flat for Item Physics.
 *
 * Wraps the vanilla renderer instead of replacing it: HEAD pushes a matrix and
 * tilts the item, RETURN pops it. RETURN fires at every return point, so the
 * push/pop stay balanced even if vanilla bails out early.
 *
 * 1.21.2+ renders entities from render states, so the target is
 * render(ItemEntityRenderState, MatrixStack, VertexConsumerProvider, int).
 * Nothing is read off the render state itself, which keeps this mixin working
 * even when fields on that class get renamed.
 */
@Mixin(ItemEntityRenderer.class)
public class ItemEntityRendererMixin {
	@Inject(method = "render", at = @At("HEAD"))
	private void spectra$itemPhysicsHead(ItemEntityRenderState state, MatrixStack matrices,
			VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
		matrices.push();

		ItemPhysics physics = Spectra.modules().get(ItemPhysics.class);
		if (physics == null || !physics.hasTransform()) return;

		// Order matters: drop to the ground first, then tilt around that point,
		// otherwise the tilt lifts the item back off the surface.
		float height = physics.getHeight();
		if (height != 0f) matrices.translate(0f, height, 0f);

		float tilt = physics.getTilt();
		if (tilt != 0f) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(tilt));

		float scale = physics.getScale();
		if (scale != 1f) matrices.scale(scale, scale, scale);
	}

	@Inject(method = "render", at = @At("RETURN"))
	private void spectra$itemPhysicsReturn(ItemEntityRenderState state, MatrixStack matrices,
			VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
		matrices.pop();
	}
}
