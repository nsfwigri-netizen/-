package dev.spectra.mixin;

import dev.spectra.module.ModuleManager;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Routes raw key presses to module keybinds.
 *
 * Vanilla KeyBinding objects are not used here: module binds are stored as raw
 * GLFW codes in the config and are rebound inside the Spectra menu, so they must
 * be read before the vanilla keybind system claims the key.
 *
 * Guards: only GLFW_PRESS (no repeats, no release) and only with no screen open,
 * so typing in chat, the search box or a bind listener never toggles modules.
 */
@Mixin(Keyboard.class)
public class KeyboardMixin {
	@Inject(method = "onKey(JIIII)V", at = @At("HEAD"))
	private void spectra$onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
		if (action != GLFW.GLFW_PRESS) return;
		if (key == GLFW.GLFW_KEY_UNKNOWN) return;

		MinecraftClient client = MinecraftClient.getInstance();
		if (client == null || client.currentScreen != null || client.player == null) return;

		ModuleManager.onKeyPressed(key);
	}
}
