package dev.spectra.mixin;

import dev.spectra.Spectra;
import dev.spectra.modules.utility.LockSlot;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cancels inventory clicks that would move an item out of a locked hotbar slot.
 *
 * WHY THE INVENTORY CHECK: Slot#getIndex() is an index inside the slot's own
 * inventory, not inside the screen. In a chest the bottom nine container slots
 * also report 0..8, so the old index-only test locked the wrong slots and broke
 * container interaction. Requiring the backing inventory to be the player's
 * makes 0..8 mean the hotbar and nothing else.
 */
@Mixin(HandledScreen.class)
public class HandledScreenMixin {
	@Inject(method = "onMouseClick(Lnet/minecraft/screen/slot/Slot;IILnet/minecraft/screen/slot/SlotActionType;)V",
			at = @At("HEAD"), cancellable = true)
	private void spectra$lockSlot(Slot slot, int slotId, int button, SlotActionType actionType, CallbackInfo ci) {
		LockSlot lockSlot = Spectra.modules().get(LockSlot.class);
		if (lockSlot == null || !lockSlot.isEnabled()) return;
		if (slot == null || !(slot.inventory instanceof PlayerInventory)) return;

		if (lockSlot.isLocked(slot.getIndex())) {
			ci.cancel();
		}
	}
}
