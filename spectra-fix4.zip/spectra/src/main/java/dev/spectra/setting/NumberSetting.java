package dev.spectra.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class NumberSetting extends Setting<Double> {
	private final double min;
	private final double max;
	private final double step;

	public NumberSetting(String name, double defaultValue, double min, double max, double step) {
		super(name, defaultValue);
		this.min = min;
		this.max = max;
		this.step = step;
	}

	@Override
	public void setValue(Double value) {
		double clamped = Math.max(min, Math.min(max, value));
		double snapped = Math.round(clamped / step) * step;
		super.setValue(snapped);
	}

	/** Sets the value from a 0..1 slider position. */
	public void setFromFraction(double fraction) {
		setValue(min + (max - min) * Math.max(0.0, Math.min(1.0, fraction)));
	}

	public double getFraction() {
		return (getValue() - min) / (max - min);
	}

	public float getFloat() {
		return getValue().floatValue();
	}

	public int getInt() {
		return (int) Math.round(getValue());
	}

	/** Smallest meaningful change, used for tap-to-nudge in the GUI. */
	public double getStep() {
		return step;
	}

	public void nudge(int direction) {
		setValue(getValue() + step * direction);
	}

	public double getMin() {
		return min;
	}

	public double getMax() {
		return max;
	}

	@Override
	public JsonElement save() {
		return new JsonPrimitive(getValue());
	}

	@Override
	public void load(JsonElement element) {
		setValue(element.getAsDouble());
	}
}
