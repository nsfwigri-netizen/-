package dev.spectra.modules.visual;

import dev.spectra.module.Category;
import dev.spectra.module.Module;
import dev.spectra.setting.BooleanSetting;
import dev.spectra.setting.ModeSetting;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.util.Hand;

/**
 * Lights up the item held in first person.
 *
 * Mobile-friendly by design: this only overrides the lightmap coordinate passed
 * to the held item renderer, so nothing in the world changes and no chunk
 * rebuild is triggered. The expensive "real" item light (a dynamic light source
 * in the world) is deliberately not implemented.
 *
 * Enforcement point: HeldItemRendererMixin#spectra$itemLight (ModifyVariable on
 * the light argument of renderFirstPersonItem).
 */
public class ItemLight extends Module {
	public final BooleanSetting mainHand = add(new BooleanSetting("Main hand", true));
	public final BooleanSetting offHand = add(new BooleanSetting("Off hand", true));
	public final ModeSetting brightness = add(new ModeSetting("Brightness", "Full", "Full", "Bright", "Soft"));

	public ItemLight() {
		super("Item Light", "Brightens the item in your hand without touching world lighting.", Category.VISUALS);
	}

	public boolean appliesTo(Hand hand) {
		if (!isEnabled()) return false;
		return hand == Hand.MAIN_HAND ? mainHand.getValue() : offHand.getValue();
	}

	/**
	 * Returns the lightmap coordinate to render with, or the original value when
	 * the module does not apply.
	 *
	 * A lightmap coordinate packs block light in the low 16 bits and sky light in
	 * the high 16 bits, each as level * 16. MAX_LIGHT_COORDINATE is level 15 on
	 * both; the softer modes pack a lower block-light level the same way while
	 * keeping the original sky light, so the item still reads as being indoors.
	 */
	public int apply(int light, Hand hand) {
		if (!appliesTo(hand)) return light;

		if (brightness.is("Full")) {
			return LightmapTextureManager.MAX_LIGHT_COORDINATE;
		}

		int blockLevel = brightness.is("Bright") ? 13 : 10;
		int skyLight = light >> 16 & 0xFFFF;
		int blockLight = light & 0xFFFF;
		return Math.max(blockLight, blockLevel * 16) | skyLight << 16;
	}
}
