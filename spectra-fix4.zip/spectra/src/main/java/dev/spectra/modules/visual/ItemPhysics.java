package dev.spectra.modules.visual;

import dev.spectra.module.Category;
import dev.spectra.module.Module;
import dev.spectra.setting.NumberSetting;

/**
 * Makes dropped items lie on the ground instead of floating upright.
 *
 * Deliberately a transform-only module: it wraps the vanilla item entity render
 * with an extra rotation instead of re-implementing the renderer. That keeps it
 * free on mobile and immune to render-state changes between versions.
 *
 * What it does NOT do (on purpose): no collision, no stacking of dropped items,
 * and the vanilla bob/spin still drives the item. Those need a custom renderer
 * plus per-entity state, which is not worth the frame cost on a phone.
 *
 * Enforcement point: ItemEntityRendererMixin (HEAD push / RETURN pop).
 */
public class ItemPhysics extends Module {
	public final NumberSetting tilt = add(new NumberSetting("Tilt", 90.0, 0.0, 90.0, 5.0));
	public final NumberSetting height = add(new NumberSetting("Height", -0.06, -0.15, 0.20, 0.01));
	public final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.5, 1.5, 0.05));

	public ItemPhysics() {
		super("Item Physics", "Dropped items lie flat on the ground instead of standing upright.", Category.VISUALS);
	}

	public float getTilt() {
		return tilt.getFloat();
	}

	public float getHeight() {
		return height.getFloat();
	}

	public float getScale() {
		return scale.getFloat();
	}

	/** True when there is anything to apply at all, so the mixin can bail out early. */
	public boolean hasTransform() {
		return isEnabled() && (getTilt() != 0f || getHeight() != 0f || getScale() != 1f);
	}
}
