package dev.spectra.mixin;

import dev.spectra.Spectra;
import dev.spectra.modules.visual.SwingAnimation;
import dev.spectra.modules.visual.ViewModel;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * First-person item transforms for View Model and Swing Animation styles.
 *
 * Target on 1.21.4 (private, so the signature must match exactly):
 *   private void renderFirstPersonItem(AbstractClientPlayerEntity player, float tickDelta,
 *       float pitch, Hand hand, float swingProgress, ItemStack item, float equipProgress,
 *       MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light)
 *
 * HEAD pushes a matrix and applies the transform, RETURN pops it. RETURN fires at every
 * return point, so push/pop stay balanced even when the method bails out early.
 */
@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
	@Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
	private void spectra$transformHead(AbstractClientPlayerEntity player, float tickDelta, float pitch,
			Hand hand, float swingProgress, ItemStack item, float equipProgress,
			MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
		matrices.push();

		boolean mainHand = hand == Hand.MAIN_HAND;

		ViewModel viewModel = Spectra.modules().get(ViewModel.class);
		if (viewModel != null && viewModel.isEnabled() && viewModel.appliesTo(mainHand)) {
			matrices.translate(viewModel.x(mainHand), viewModel.y(), viewModel.z());
			if (viewModel.rotX() != 0f) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(viewModel.rotX()));
			if (viewModel.rotY(mainHand) != 0f) matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(viewModel.rotY(mainHand)));
			if (viewModel.rotZ(mainHand) != 0f) matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(viewModel.rotZ(mainHand)));
			float scale = viewModel.scale();
			if (scale != 1f) matrices.scale(scale, scale, scale);
		}

		SwingAnimation swing = Spectra.modules().get(SwingAnimation.class);
		if (swing != null && swing.isEnabled() && swing.hasStyle()) {
			spectra$applyStyle(matrices, swing.getStyle(), swingProgress, swing.getStrength(), mainHand);
		}
	}

	@Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
	private void spectra$transformReturn(AbstractClientPlayerEntity player, float tickDelta, float pitch,
			Hand hand, float swingProgress, ItemStack item, float equipProgress,
			MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
		matrices.pop();
	}

	/**
	 * Approximate position of the held item in camera space, taken from the vanilla
	 * equip offsets in HeldItemRenderer (x is mirrored for the offhand).
	 *
	 * WHY THIS EXISTS: at HEAD we are still in camera space, where the origin is the
	 * player's eye. Rotating there does not spin the item, it swings the item around
	 * the camera on a ~0.9 block radius arc, which threw the sword across the screen
	 * (most visible with Spin's 360 degrees) and made the smaller styles look broken.
	 * Rotations are now applied around this pivot, so the item turns in place.
	 */
	private static final float PIVOT_X = 0.56f;
	private static final float PIVOT_Y = -0.52f;
	private static final float PIVOT_Z = -0.72f;

	private static void spectra$applyStyle(MatrixStack matrices, String style, float progress,
			float strength, boolean mainHand) {
		float side = mainHand ? 1f : -1f;

		// static part of a style: applies whether or not we are mid-swing
		if ("Old 1.7".equals(style)) {
			matrices.translate(0f, -0.07f, 0.04f);
		}

		if (progress <= 0f) return;

		// sin curve so the motion starts and ends at rest instead of snapping back
		float wave = (float) Math.sin(progress * Math.PI) * strength;

		float tx = 0f, ty = 0f, tz = 0f;
		float rx = 0f, ry = 0f, rz = 0f;
		float shrink = 1f;

		switch (style) {
			case "Slide" -> {
				tx = -wave * 0.10f * side;
				tz = wave * 0.05f;
				rz = wave * 18f * side;
			}
			case "Stab" -> {
				tz = -wave * 0.14f;
				rx = -wave * 14f;
			}
			case "Swank" -> {
				tx = -wave * 0.06f * side;
				ty = wave * 0.04f;
				rz = wave * 34f * side;
				rx = -wave * 18f;
			}
			case "Spin" -> {
				// A full 360 roll cannot be made small by pivoting alone: the item sits
				// ~0.72 blocks from the eye, where half the screen is only ~0.5 blocks
				// wide, so a 0.3 block long sword sweeps most of the view. Pushing the
				// item away and shrinking it during the turn is what actually keeps the
				// arc inside the screen.
				rz = progress * 360f * strength * side;
				tz = -0.16f * wave;
				shrink = 1f - 0.35f * Math.min(1f, wave);
			}
			case "Exhibition" -> {
				tx = wave * 0.04f * side;
				ty = -wave * 0.05f;
				rx = wave * 40f;
				ry = wave * 10f * side;
			}
			case "Old 1.7" -> {
				// 1.7 held the item lower and swung it with less Z travel
				rz = wave * 10f * side;
				rx = -wave * 6f;
			}
			default -> {
				return;
			}
		}

		matrices.translate(tx, ty, tz);

		if (rx != 0f || ry != 0f || rz != 0f || shrink != 1f) {
			// T(pivot) * R * S * T(-pivot): rotates and scales the item about itself
			float pivotX = PIVOT_X * side;
			matrices.translate(pivotX, PIVOT_Y, PIVOT_Z);
			if (rx != 0f) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rx));
			if (ry != 0f) matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(ry));
			if (rz != 0f) matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rz));
			if (shrink != 1f) matrices.scale(shrink, shrink, shrink);
			matrices.translate(-pivotX, -PIVOT_Y, -PIVOT_Z);
		}
	}
}
